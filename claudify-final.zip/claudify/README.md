# Claudify

A production-ready digital-products e-commerce site for the Algerian market — Next.js 14
(App Router) + TypeScript + Tailwind CSS + Prisma/PostgreSQL, Chargily Pay via polling
(no webhooks), and a private owner admin dashboard.

## Status: build complete

All 6 planned steps are done: storefront, cart/checkout/delivery, Chargily Pay integration +
polling sync engine, the admin dashboard, and final hardening/verification. See
`QA_CHECKLIST.md` for a step-by-step test pass to run locally.

---

## Quick start

```bash
npm install
cp .env.example .env
# Fill in DATABASE_URL, DIRECT_URL, ADMIN_SEED_EMAIL, ADMIN_SEED_PASSWORD — see below

npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

- Storefront: http://localhost:3000
- Admin dashboard: http://localhost:3000/admin/login (sign in with `ADMIN_SEED_EMAIL` /
  `ADMIN_SEED_PASSWORD`, then **change the password immediately** from
  `/admin/settings/account`)

The site works fully end-to-end right now — including a real purchase and file download —
without any Chargily credentials, via the built-in mock payment mode described below.

---

## What was built

### Public storefront
Homepage, full catalog with search/filter/sort, product detail pages, FAQ — responsive across
mobile/tablet/desktop, with a distinct visual identity (not a generic template).

### Commerce
Cart (no account required), checkout, order status page, and secure digital delivery — download
links are minted only when clicked, single-use, expire in 10 minutes, and are checked against
what that specific order actually paid for.

### Chargily Pay
Real integration against Chargily's official API docs (`lib/chargily.ts`) — defaults to a safe
**mock mode** with a built-in payment simulator until you add real credentials, so you can test
the entire flow today. Test/live API base URL is chosen automatically from your key's prefix.

### Polling sync engine (no webhooks)
Idempotent order reconciliation, retry-with-backoff, run logging, and automatic alerts on
repeated failures — interval configurable from the admin dashboard (15 min / 30 min / hourly /
daily), triggerable via a secret-protected HTTP endpoint or a CLI script for VPS crontab.

### Admin dashboard (`/admin`)
A genuinely separate area — its own root layout, its own auth (DB-backed sessions, rate-limited
login), `noindex`/`no-store` everywhere, nothing links to it from the public site. Products
(full CRUD + file uploads), orders (with manual, confirmation-gated status overrides),
customers, live analytics, alerts, and sync settings.

### Hardening (this step)
- Rate limiting on checkout, order-status checks, and admin login (in-memory, documented
  limitation for multi-instance serverless hosting)
- Security headers: HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy,
  Permissions-Policy, plus `no-store`/`noindex` on admin and order pages specifically
- Error boundaries on both the storefront and admin so a single failed page never crashes
  the whole app or leaks a stack trace
- Skip-to-content link and visible focus states for keyboard navigation
- Loading skeletons on key routes instead of blank screens during data fetches
- ISR revalidation as a time-based safety net alongside the on-demand cache invalidation
  admin edits already trigger

---

## Required environment variables

| Variable | Required | Notes |
|---|---|---|
| `DATABASE_URL` | Yes | Runtime connection (pooled, if your provider offers one) |
| `DIRECT_URL` | Yes | Direct connection, used only for migrations — see `.env.example` for provider-specific notes (Neon: same value as `DATABASE_URL`; Supabase: different port + username format) |
| `ADMIN_SEED_EMAIL` / `ADMIN_SEED_PASSWORD` | For seeding | Change the password from the dashboard after first login |
| `CHARGILY_MODE` | No (defaults to `mock`) | Set to `live` once you have real credentials |
| `CHARGILY_SECRET_KEY` | Only in live mode | Server-side only, never exposed to the client |
| `APP_URL` | Only in live mode | Your real public site URL |
| `CRON_SECRET` | For the sync scheduler | Long random string, e.g. `openssl rand -hex 32` |

Full details and examples are in `.env.example`.

---

## Remaining configuration steps (yours to do)

1. **Chargily credentials** — once you have them, set `CHARGILY_MODE=live`,
   `CHARGILY_SECRET_KEY`, and `APP_URL`, then test a real purchase in Chargily's test mode
   before going live.
2. **Sync scheduler** — point a free external scheduler (cron-job.org, a scheduled GitHub
   Action) at `POST /api/cron/sync?secret=YOUR_CRON_SECRET` every ~15 minutes, or use
   `npm run sync:run` from a VPS crontab. Full instructions in the "Payments & sync" section
   below.
3. **Real product files** — replace the placeholder files in `private-storage/` and upload
   real cover images/deliverables from the admin dashboard.
4. **File storage for production, if deploying serverless** (e.g. Vercel) — the local-disk
   storage used for uploads (`lib/storage.ts`, product files, and cover images) doesn't
   persist on an ephemeral filesystem. Swap in an S3-compatible adapter (AWS S3, Cloudflare
   R2, Backblaze B2) before relying on uploads in that kind of deployment. A VPS with a
   persistent disk needs no change.
5. **Run through `QA_CHECKLIST.md`** end to end and let me know what needs fixing.

---

## How to access the admin dashboard

Go to `/admin/login` and sign in with the credentials you set in `ADMIN_SEED_EMAIL` /
`ADMIN_SEED_PASSWORD` before running `npm run db:seed`. Change the password immediately from
`/admin/settings/account`. There's no link to `/admin` anywhere on the public site — it's
reached only by typing the URL directly, and is protected independently of the storefront
(separate layout, separate auth, separate everything).

---

## Payments & sync — setup detail

**Scheduler options (pick one, both call the same engine):**

- **External HTTP pinger** (works on any low-cost host): point a free scheduler at
  `POST /api/cron/sync?secret=YOUR_CRON_SECRET` every 15 minutes. A real sync only runs once
  the interval configured in `/admin/settings/sync` has actually elapsed — the external
  trigger can fire more often than that with no ill effect.
- **Self-hosted crontab**: `*/15 * * * * cd /path/to/claudify && npm run sync:run >> sync.log 2>&1`

**Why polling, not webhooks:** per the project requirements. The `PaymentEvent` table is a
generic, provider-agnostic ledger, so a webhook endpoint can be added later (calling the same
`markOrderPaid`/`markOrderFailed` functions in `lib/orders.ts`) without restructuring anything.

---

## Project structure

```
app/(storefront)/          Public site — its own root layout
app/admin/                 Admin dashboard — a genuinely separate root layout
  (auth)/login/            Login (no auth required)
  (protected)/             Everything else — gated by its layout.tsx
app/api/checkout/          Order creation + Chargily session
app/api/orders/[token]/    Status check, mock-mode simulator, file download minting
app/api/cron/sync/         HTTP trigger for the polling sync engine
app/downloads/[token]/     The only route that touches private file storage
lib/chargily.ts            Chargily Pay client (real API calls, mock mode by default)
lib/sync/                  Polling engine: reconciliation, retry, logging
lib/orders.ts              Order state transitions — the only place status changes happen
lib/download-tokens.ts     Signed, single-use, ownership-checked download tokens
lib/storage.ts             File storage adapter (local disk now, S3-ready later)
lib/rate-limit.ts          In-memory rate limiting for public routes
lib/admin/                 Admin auth, services (reads), actions (writes)
lib/services/              Public-facing Prisma data access
prisma/schema.prisma       Full database schema
prisma/seed.ts             Idempotent seed script (catalog + owner admin account)
private-storage/           Placeholder deliverable files — replace with the real ones
QA_CHECKLIST.md            Manual end-to-end verification checklist
```
