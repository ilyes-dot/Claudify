'use client'

import Link from 'next/link'
import { useEffect } from 'react'

export default function StorefrontError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <div className="container-page flex min-h-[60vh] flex-col items-center justify-center py-24 text-center">
      <span className="font-mono text-sm text-ink/40">Something went wrong</span>
      <h1 className="mt-3 font-display text-2xl font-semibold text-ink">
        This page hit a snag
      </h1>
      <p className="mt-2 max-w-sm text-ink/60">
        Nothing was lost — try again, or head back to the catalog.
      </p>
      <div className="mt-8 flex gap-3">
        <button onClick={reset} className="rounded-full border border-line px-6 py-3 text-sm font-medium text-ink hover:border-signal hover:text-signal">
          Try again
        </button>
        <Link href="/products" className="rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white">
          Browse the catalog
        </Link>
      </div>
    </div>
  )
}
