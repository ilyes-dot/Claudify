import { Suspense } from 'react'
import type { Metadata } from 'next'
import { ProductCatalog } from '@/components/product-catalog'
import { getPublishedProducts } from '@/lib/services/products'
import { getCategories } from '@/lib/services/categories'

export const metadata: Metadata = {
  title: 'All products',
  description: 'Browse templates, courses, guides, software and design assets on Claudify.',
}

export const revalidate = 3600

export default async function ProductsPage() {
  const [products, categories] = await Promise.all([getPublishedProducts(), getCategories()])

  return (
    <div className="container-page py-14">
      <div className="max-w-lg">
        <h1 className="font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
          The full catalog
        </h1>
        <p className="mt-3 text-ink/60">
          {products.length} products, ready to unlock the moment you check out.
        </p>
      </div>

      <div className="mt-8">
        <Suspense fallback={null}>
          <ProductCatalog products={products} categories={categories} />
        </Suspense>
      </div>
    </div>
  )
}
