import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import {
  getProductBySlug,
  getPublishedProducts,
  getRelatedProducts,
  getProductSalesCount,
} from '@/lib/services/products'
import { formatDZD, formatFileSize } from '@/lib/utils'
import { ProductCard } from '@/components/product-card'
import { VerifiedSeal } from '@/components/verified-seal'
import { BuyNowButton } from '@/components/buy-now-button'
import { AddToCartButton } from '@/components/add-to-cart-button'

export const revalidate = 3600

export async function generateStaticParams() {
  const products = await getPublishedProducts()
  return products.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await getProductBySlug(params.slug)
  if (!product) return {}
  return {
    title: product.title,
    description: product.tagline,
    openGraph: { title: product.title, description: product.tagline },
  }
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug)
  if (!product) notFound()

  const [related, salesCount] = await Promise.all([
    getRelatedProducts(product.categoryId, product.id),
    getProductSalesCount(product.id),
  ])

  const discount = product.compareAtDZD
    ? Math.round(100 - (product.priceDZD / product.compareAtDZD) * 100)
    : null

  const fileFormats = product.files.map((f) => f.label.match(/\(([^)]+)\)/)?.[1] ?? f.label).join(', ')
  const totalSize = product.files.reduce((sum, f) => sum + f.sizeBytes, 0)

  return (
    <div className="container-page py-12">
      <nav className="mb-8 flex items-center gap-2 text-sm text-ink/50" aria-label="Breadcrumb">
        <Link href="/products" className="hover:text-ink">Catalog</Link>
        <span aria-hidden>/</span>
        <Link href={`/products?category=${product.category.slug}`} className="hover:text-ink">
          {product.category.name}
        </Link>
        <span aria-hidden>/</span>
        <span className="text-ink/70">{product.title}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="deed-corner relative aspect-[4/3] overflow-hidden rounded-card bg-ink">
          <Image src={product.coverImage} alt="" fill className="object-cover" priority sizes="(min-width: 1024px) 55vw, 100vw" />
        </div>

        <div>
          <span className="text-xs font-medium uppercase tracking-wide text-signal">
            {product.category.name}
          </span>
          <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
            {product.title}
          </h1>
          <p className="mt-3 text-lg text-ink/60">{product.tagline}</p>

          <div className="mt-6 flex items-center gap-2 text-sm text-ink/55">
            <StarRow rating={product.displayRating} />
            <span>{product.displayRating.toFixed(1)}</span>
            <span aria-hidden>&middot;</span>
            <span>{product.displayReviewCount} reviews</span>
            <span aria-hidden>&middot;</span>
            <span>{salesCount.toLocaleString()} sold</span>
          </div>

          <div className="mt-8 rounded-card border border-line bg-paper-raised p-6 shadow-card">
            <div className="flex items-end justify-between">
              <div className="flex items-baseline gap-3">
                <span className="price text-3xl font-semibold">{formatDZD(product.priceDZD)}</span>
                {product.compareAtDZD && (
                  <span className="font-mono text-sm text-ink/35 line-through">
                    {formatDZD(product.compareAtDZD)}
                  </span>
                )}
              </div>
              {discount && (
                <span className="rounded-full bg-gold/15 px-3 py-1 text-xs font-semibold text-gold">
                  Save {discount}%
                </span>
              )}
            </div>

            <BuyNowButton
              productId={product.id}
              slug={product.slug}
              title={product.title}
              priceDZD={product.priceDZD}
              coverImage={product.coverImage}
            />
            <AddToCartButton
              productId={product.id}
              slug={product.slug}
              title={product.title}
              priceDZD={product.priceDZD}
              coverImage={product.coverImage}
            />

            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-ink/50">
              <VerifiedSeal size={16} />
              Secured by Chargily Pay &middot; {fileFormats} &middot; {formatFileSize(totalSize)}
            </div>
          </div>

          <ul className="mt-8 space-y-3">
            {product.benefits.map((b) => (
              <li key={b} className="flex items-start gap-3 text-sm text-ink/75">
                <CheckIcon />
                {b}
              </li>
            ))}
          </ul>

          <p className="mt-6 text-xs text-ink/40">{product.licenseNote}</p>
        </div>
      </div>

      <div className="mt-16 max-w-2xl">
        <h2 className="font-display text-xl font-semibold text-ink">About this product</h2>
        <p className="mt-3 leading-relaxed text-ink/65">{product.description}</p>
      </div>

      {related.length > 0 && (
        <div className="mt-20">
          <h2 className="font-display text-2xl font-semibold text-ink">You might also like</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function StarRow({ rating }: { rating: number }) {
  return (
    <div className="flex" aria-hidden>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} width="14" height="14" viewBox="0 0 16 16" fill={i < Math.round(rating) ? '#C89B3C' : '#0B122022'}>
          <path d="M8 1l1.9 4.5 4.9.4-3.7 3.2 1.1 4.8L8 11.6 3.8 13.9l1.1-4.8L1.2 5.9l4.9-.4z" />
        </svg>
      ))}
    </div>
  )
}

function CheckIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="mt-0.5 shrink-0" aria-hidden>
      <circle cx="8" cy="8" r="8" fill="#1E8E5A" fillOpacity="0.15" />
      <path d="M5 8.2l2 2 4-4.4" stroke="#1E8E5A" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
