export default function ProductsLoading() {
  return (
    <div className="container-page py-14">
      <div className="h-9 w-64 animate-pulse rounded-lg bg-ink/5" />
      <div className="mt-3 h-5 w-40 animate-pulse rounded-lg bg-ink/5" />
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="overflow-hidden rounded-card border border-line bg-paper-raised shadow-card">
            <div className="aspect-[4/3] animate-pulse bg-ink/5" />
            <div className="space-y-2 p-4">
              <div className="h-3 w-20 animate-pulse rounded bg-ink/5" />
              <div className="h-4 w-full animate-pulse rounded bg-ink/5" />
              <div className="h-3 w-2/3 animate-pulse rounded bg-ink/5" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
