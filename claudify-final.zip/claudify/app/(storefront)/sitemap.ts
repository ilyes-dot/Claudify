import type { MetadataRoute } from 'next'
import { getPublishedProducts } from '@/lib/services/products'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = 'https://claudify.dz'
  const products = await getPublishedProducts()
  const productRoutes = products.map((p) => ({
    url: `${base}/products/${p.slug}`,
    changeFrequency: 'weekly' as const,
    priority: 0.7,
  }))

  return [
    { url: base, changeFrequency: 'weekly', priority: 1 },
    { url: `${base}/products`, changeFrequency: 'daily', priority: 0.9 },
    { url: `${base}/faq`, changeFrequency: 'monthly', priority: 0.4 },
    ...productRoutes,
  ]
}
