import { NextRequest, NextResponse } from 'next/server'
import { verifyAndConsumeToken } from '@/lib/download-tokens'
import { getFileStream } from '@/lib/storage'

// Needs Node's fs module (via lib/storage.ts) — not compatible with the Edge runtime.
export const runtime = 'nodejs'

export async function GET(req: NextRequest, { params }: { params: { token: string } }) {
  let target: { storageKey: string; fileName: string }
  try {
    target = await verifyAndConsumeToken(params.token)
  } catch (err) {
    const message = err instanceof Error ? err.message : 'INVALID_TOKEN'
    const status = message === 'EXPIRED_TOKEN' || message === 'TOKEN_ALREADY_USED' ? 410 : 403
    return NextResponse.json({ error: message }, { status })
  }

  try {
    const { stream, sizeBytes } = await getFileStream(target.storageKey)
    return new NextResponse(stream, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(sizeBytes),
        'Content-Disposition': `attachment; filename="${sanitizeFilename(target.fileName)}"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'File unavailable' },
      { status: 500 }
    )
  }
}

function sanitizeFilename(name: string): string {
  return name.replace(/[^a-zA-Z0-9 ._-]/g, '').slice(0, 120) || 'download'
}
