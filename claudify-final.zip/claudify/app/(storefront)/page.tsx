import { Hero } from '@/components/hero'
import { CategoryGrid } from '@/components/category-grid'
import { FeaturedProducts } from '@/components/featured-products'
import { HowItWorks } from '@/components/how-it-works'
import { Testimonials } from '@/components/testimonials'
import { FaqSection } from '@/components/faq-section'
import { CtaSection } from '@/components/cta-section'

// Safety-net cache duration — admin edits trigger an immediate on-demand
// revalidation via revalidatePath, so this just bounds worst-case staleness
// if that were ever missed.
export const revalidate = 3600

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedProducts />
      <CategoryGrid />
      <HowItWorks />
      <Testimonials />
      <FaqSection />
      <CtaSection />
    </>
  )
}
