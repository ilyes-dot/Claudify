'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useCart } from '@/components/cart-provider'
import { formatDZD } from '@/lib/utils'

export default function CartPage() {
  const { items, removeItem, setQuantity, totalDZD, totalCount } = useCart()

  if (items.length === 0) {
    return (
      <div className="container-page flex min-h-[50vh] flex-col items-center justify-center py-24 text-center">
        <h1 className="font-display text-2xl font-semibold text-ink">Your cart is empty</h1>
        <p className="mt-2 text-ink/60">Add a product from the catalog to get started.</p>
        <Link href="/products" className="mt-8 rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white">
          Browse the catalog
        </Link>
      </div>
    )
  }

  return (
    <div className="container-page py-14">
      <h1 className="font-display text-3xl font-semibold tracking-tight text-ink">
        Your cart <span className="text-ink/40">({totalCount})</span>
      </h1>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_340px]">
        <ul className="space-y-4">
          {items.map((item) => (
            <li
              key={item.productId}
              className="flex items-center gap-4 rounded-card border border-line bg-paper-raised p-4 shadow-card"
            >
              <div className="relative h-20 w-24 shrink-0 overflow-hidden rounded-lg bg-ink">
                <Image src={item.coverImage} alt="" fill className="object-cover" sizes="96px" />
              </div>

              <div className="flex-1">
                <Link href={`/products/${item.slug}`} className="font-medium text-ink hover:text-signal">
                  {item.title}
                </Link>
                <p className="price mt-1 text-sm">{formatDZD(item.priceDZD)}</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setQuantity(item.productId, item.quantity - 1)}
                  aria-label="Decrease quantity"
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-ink/60 hover:border-signal hover:text-signal"
                >
                  &minus;
                </button>
                <span className="w-6 text-center font-mono text-sm">{item.quantity}</span>
                <button
                  onClick={() => setQuantity(item.productId, item.quantity + 1)}
                  aria-label="Increase quantity"
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-ink/60 hover:border-signal hover:text-signal"
                >
                  +
                </button>
              </div>

              <button
                onClick={() => removeItem(item.productId)}
                aria-label={`Remove ${item.title} from cart`}
                className="ml-2 text-sm text-ink/40 hover:text-red-600"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>

        <div className="h-fit rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <h2 className="font-display text-lg font-semibold text-ink">Order summary</h2>
          <div className="mt-4 flex items-center justify-between text-sm text-ink/60">
            <span>Subtotal</span>
            <span className="price">{formatDZD(totalDZD)}</span>
          </div>
          <div className="mt-1 flex items-center justify-between border-b border-line pb-4 text-sm text-ink/60">
            <span>Delivery</span>
            <span>Instant, digital</span>
          </div>
          <div className="mt-4 flex items-center justify-between font-semibold text-ink">
            <span>Total</span>
            <span className="price text-lg">{formatDZD(totalDZD)}</span>
          </div>

          <Link
            href="/checkout"
            className="mt-6 flex w-full items-center justify-center rounded-full bg-signal py-3.5 text-sm font-semibold text-white shadow-md shadow-signal/20 transition-transform hover:scale-[1.01]"
          >
            Proceed to checkout
          </Link>
        </div>
      </div>
    </div>
  )
}
