import { notFound, redirect } from 'next/navigation'
import { getOrderByAccessToken } from '@/lib/orders'
import { formatDZD } from '@/lib/utils'
import { MockPaymentActions } from '@/components/mock-payment-actions'

const CHARGILY_MODE = process.env.CHARGILY_MODE === 'live' ? 'live' : 'mock'

export default async function MockCheckoutPage({ params }: { params: { accessToken: string } }) {
  // This page only exists to make the full purchase flow testable before
  // real Chargily credentials are configured. It's unreachable once
  // CHARGILY_MODE=live, since lib/chargily.ts stops generating links to it.
  if (CHARGILY_MODE === 'live') {
    redirect('/')
  }

  const order = await getOrderByAccessToken(params.accessToken)
  if (!order) notFound()

  return (
    <div className="container-page flex min-h-[70vh] items-center justify-center py-14">
      <div className="w-full max-w-md rounded-card border-2 border-dashed border-gold/50 bg-paper-raised p-8 shadow-card">
        <span className="rounded-full bg-gold/15 px-3 py-1 text-xs font-semibold text-gold">
          MOCK PAYMENT GATEWAY — DEV ONLY
        </span>
        <h1 className="mt-4 font-display text-xl font-semibold text-ink">Simulated Chargily checkout</h1>
        <p className="mt-2 text-sm text-ink/60">
          Real card entry happens on Chargily&rsquo;s hosted page once credentials are configured.
          This screen stands in for that page so you can test the full flow today.
        </p>

        <div className="mt-6 rounded-lg border border-line bg-paper px-4 py-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-ink/60">Order</span>
            <span className="font-mono">{order.orderNumber}</span>
          </div>
          <div className="mt-1 flex items-center justify-between text-sm">
            <span className="text-ink/60">Amount</span>
            <span className="price font-semibold">{formatDZD(order.totalDZD)}</span>
          </div>
        </div>

        <MockPaymentActions accessToken={order.accessToken} />
      </div>
    </div>
  )
}
