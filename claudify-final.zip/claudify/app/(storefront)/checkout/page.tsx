'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useCart } from '@/components/cart-provider'
import { formatDZD } from '@/lib/utils'
import { VerifiedSeal } from '@/components/verified-seal'

export default function CheckoutPage() {
  const { items, totalDZD, clear } = useCart()
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      const res = await fetch('/api/checkout/create-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Something went wrong. Please try again.')
        setSubmitting(false)
        return
      }
      clear()
      router.push(data.checkoutUrl)
    } catch {
      setError('Network error — please check your connection and try again.')
      setSubmitting(false)
    }
  }

  if (items.length === 0) {
    return (
      <div className="container-page flex min-h-[50vh] flex-col items-center justify-center py-24 text-center">
        <h1 className="font-display text-2xl font-semibold text-ink">Nothing to check out</h1>
        <p className="mt-2 text-ink/60">Your cart is empty.</p>
        <Link href="/products" className="mt-8 rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white">
          Browse the catalog
        </Link>
      </div>
    )
  }

  return (
    <div className="container-page py-14">
      <h1 className="font-display text-3xl font-semibold tracking-tight text-ink">Checkout</h1>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_360px]">
        <form onSubmit={handleSubmit} className="rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <label htmlFor="email" className="text-sm font-medium text-ink">
            Email address
          </label>
          <p className="mt-1 text-xs text-ink/50">
            Your receipt and download links are sent here — no account needed.
          </p>
          <input
            id="email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="mt-2 w-full rounded-lg border border-line bg-paper px-4 py-3 text-sm outline-none focus-visible:border-signal"
          />

          {error && (
            <p role="alert" className="mt-4 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="mt-6 flex w-full items-center justify-center rounded-full bg-signal py-3.5 text-sm font-semibold text-white shadow-md shadow-signal/20 transition-transform hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {submitting ? 'Preparing secure checkout…' : 'Continue to payment'}
          </button>

          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-ink/50">
            <VerifiedSeal size={16} />
            Payment is handled securely by Chargily Pay
          </div>
        </form>

        <div className="h-fit rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <h2 className="font-display text-lg font-semibold text-ink">Order summary</h2>
          <ul className="mt-4 space-y-3">
            {items.map((item) => (
              <li key={item.productId} className="flex items-center justify-between text-sm">
                <span className="text-ink/75">
                  {item.title} {item.quantity > 1 && <span className="text-ink/40">&times;{item.quantity}</span>}
                </span>
                <span className="price">{formatDZD(item.priceDZD * item.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex items-center justify-between border-t border-line pt-4 font-semibold text-ink">
            <span>Total</span>
            <span className="price text-lg">{formatDZD(totalDZD)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
