import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getOrderByAccessToken } from '@/lib/orders'
import { prisma } from '@/lib/prisma'
import { formatDZD } from '@/lib/utils'
import { VerifiedSeal } from '@/components/verified-seal'
import { CheckStatusButton } from '@/components/check-status-button'

const statusCopy: Record<string, { label: string; tone: string }> = {
  pending: { label: 'Starting checkout…', tone: 'bg-ink/10 text-ink/60' },
  awaiting_payment: { label: 'Awaiting payment', tone: 'bg-gold/15 text-gold' },
  paid: { label: 'Paid', tone: 'bg-verified/15 text-verified' },
  failed: { label: 'Payment failed', tone: 'bg-red-100 text-red-700' },
  expired: { label: 'Checkout expired', tone: 'bg-ink/10 text-ink/60' },
  refunded: { label: 'Refunded', tone: 'bg-ink/10 text-ink/60' },
}

export default async function OrderStatusPage({ params }: { params: { accessToken: string } }) {
  const order = await getOrderByAccessToken(params.accessToken)
  if (!order) notFound()

  const status = statusCopy[order.status] ?? statusCopy.pending
  const isPaid = order.status === 'paid'

  const files = isPaid
    ? await prisma.productFile.findMany({
        where: { productId: { in: order.items.map((i) => i.productId) } },
        orderBy: { sortOrder: 'asc' },
      })
    : []

  return (
    <div className="container-page py-14">
      <div className="mx-auto max-w-xl">
        <div className="deed-corner rounded-card border border-line bg-paper-raised p-8 shadow-card">
          <div className="flex items-center justify-between border-b border-line pb-5">
            <div>
              <p className="font-mono text-xs text-ink/40">ORDER {order.orderNumber}</p>
              <p className="mt-1 text-xs text-ink/40">
                Placed {order.createdAt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
              </p>
            </div>
            <span className={`rounded-full px-3 py-1.5 text-xs font-semibold ${status.tone}`}>
              {status.label}
            </span>
          </div>

          <ul className="mt-5 space-y-4">
            {order.items.map((item) => (
              <li key={item.id} className="flex items-center justify-between text-sm">
                <span className="text-ink/80">
                  {item.titleSnapshot}
                  {item.quantity > 1 && <span className="text-ink/40"> &times;{item.quantity}</span>}
                </span>
                <span className="price">{formatDZD(item.unitPriceDZD * item.quantity)}</span>
              </li>
            ))}
          </ul>

          <div className="mt-5 flex items-center justify-between border-t border-line pt-4 font-semibold text-ink">
            <span>Total</span>
            <span className="price text-lg">{formatDZD(order.totalDZD)}</span>
          </div>

          {isPaid ? (
            <div className="mt-6 space-y-3 border-t border-line pt-6">
              <div className="flex items-center gap-2 text-sm font-medium text-verified">
                <VerifiedSeal size={18} />
                Your files are ready
              </div>
              {files.map((file) => (
                <a
                  key={file.id}
                  href={`/api/orders/${order.accessToken}/download/${file.id}`}
                  className="flex items-center justify-between rounded-lg border border-line bg-paper px-4 py-3 text-sm font-medium text-ink hover:border-signal hover:text-signal"
                >
                  {file.label}
                  <span aria-hidden>&darr;</span>
                </a>
              ))}
              <p className="text-xs text-ink/40">
                Each download link is single-use and expires quickly for security — just revisit this page
                any time to generate a new one.
              </p>
            </div>
          ) : order.status === 'awaiting_payment' ? (
            <div className="mt-6 space-y-3 border-t border-line pt-6 text-center">
              <p className="text-sm text-ink/60">
                We haven&rsquo;t received payment confirmation yet. This usually resolves within a few minutes.
              </p>
              <CheckStatusButton accessToken={order.accessToken} />
            </div>
          ) : order.status === 'failed' ? (
            <div className="mt-6 border-t border-line pt-6 text-center">
              <p className="text-sm text-ink/60">
                {order.failureReason || 'The payment did not go through.'}
              </p>
              <Link href="/products" className="mt-4 inline-flex rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white">
                Try again
              </Link>
            </div>
          ) : null}
        </div>

        <p className="mt-4 text-center text-xs text-ink/40">
          Bookmark this page — it&rsquo;s the only place your download links live.
        </p>
      </div>
    </div>
  )
}
