import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="container-page flex min-h-[60vh] flex-col items-center justify-center py-24 text-center">
      <span className="font-mono text-sm text-ink/40">404</span>
      <h1 className="mt-3 font-display text-3xl font-semibold text-ink">This page isn&rsquo;t in the catalog</h1>
      <p className="mt-2 max-w-sm text-ink/60">
        The product or page you&rsquo;re looking for may have been renamed or removed.
      </p>
      <Link
        href="/products"
        className="mt-8 rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white"
      >
        Browse the catalog
      </Link>
    </div>
  )
}
