import type { Metadata } from 'next'
import { FaqAccordion } from '@/components/faq-accordion'
import { faqItems } from '@/lib/data/content'

export const metadata: Metadata = {
  title: 'FAQ',
  description: 'Answers to common questions about buying and receiving digital products on Claudify.',
}

export default function FaqPage() {
  return (
    <div className="container-page py-16">
      <div className="max-w-lg">
        <h1 className="font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
          Frequently asked questions
        </h1>
        <p className="mt-3 text-ink/60">
          Everything about payment, delivery, and licensing in one place.
        </p>
      </div>

      <div className="mt-10 max-w-2xl">
        <FaqAccordion items={faqItems} />
      </div>
    </div>
  )
}
