import type { Metadata } from 'next'
import { Space_Grotesk, Inter, IBM_Plex_Mono } from 'next/font/google'
import '../globals.css'
import { NavBar } from '@/components/nav-bar'
import { Footer } from '@/components/footer'
import { CartProvider } from '@/components/cart-provider'

const display = Space_Grotesk({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display',
  display: 'swap',
})
const body = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-body',
  display: 'swap',
})
const mono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://claudify.dz'),
  title: {
    default: 'Claudify — Digital products, delivered instantly',
    template: '%s | Claudify',
  },
  description:
    'Claudify is a digital-products marketplace for the Algerian market — templates, courses, guides and tools, paid securely in DA and delivered the moment your payment clears.',
  openGraph: {
    title: 'Claudify — Digital products, delivered instantly',
    description:
      'Templates, courses, guides and tools for the Algerian market. Secure checkout, instant delivery.',
    type: 'website',
    locale: 'en_DZ',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="flex min-h-screen flex-col">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-signal focus:px-5 focus:py-2.5 focus:text-sm focus:font-semibold focus:text-white"
        >
          Skip to main content
        </a>
        <CartProvider>
          <NavBar />
          <main id="main-content" className="flex-1">{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  )
}
