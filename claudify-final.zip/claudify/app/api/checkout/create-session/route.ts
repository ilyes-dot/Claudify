import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { createPendingOrder } from '@/lib/orders'
import { createCheckoutSession } from '@/lib/chargily'
import { checkRateLimit, getClientIp } from '@/lib/rate-limit'

const checkoutSchema = z.object({
  email: z.string().trim().email().max(200),
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        quantity: z.number().int().min(1).max(10),
      })
    )
    .min(1)
    .max(20),
})

export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  if (!checkRateLimit(`checkout:${ip}`, 10, 5 * 60 * 1000)) {
    return NextResponse.json(
      { error: 'Too many checkout attempts. Please wait a few minutes and try again.' },
      { status: 429 }
    )
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
  }

  const parsed = checkoutSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid checkout data', details: parsed.error.flatten() }, { status: 400 })
  }

  try {
    const order = await createPendingOrder(parsed.data)
    const session = await createCheckoutSession(order)

    await prisma.order.update({
      where: { id: order.id },
      data: { status: 'awaiting_payment', chargilyCheckoutId: session.providerCheckoutId },
    })

    return NextResponse.json({ orderAccessToken: order.accessToken, checkoutUrl: session.checkoutUrl })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Checkout failed'
    // Client-facing errors (bad/unavailable products, empty cart) vs. server
    // errors are both surfaced as 400 here since either way the client's
    // cart needs to change before retrying.
    return NextResponse.json({ error: message }, { status: 400 })
  }
}
