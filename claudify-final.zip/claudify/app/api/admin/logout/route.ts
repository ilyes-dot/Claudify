import { NextResponse } from 'next/server'
import { logout } from '@/lib/admin/auth'

export async function POST(req: Request) {
  await logout()
  return NextResponse.redirect(new URL('/admin/login', req.url))
}
