import { NextRequest, NextResponse } from 'next/server'
import { getOrderByAccessToken } from '@/lib/orders'
import { mintDownloadToken } from '@/lib/download-tokens'

export async function GET(
  req: NextRequest,
  { params }: { params: { accessToken: string; fileId: string } }
) {
  const order = await getOrderByAccessToken(params.accessToken)
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  }
  if (order.status !== 'paid') {
    return NextResponse.json({ error: 'This order has not been paid yet' }, { status: 403 })
  }

  try {
    const rawToken = await mintDownloadToken(order.id, params.fileId)
    return NextResponse.redirect(new URL(`/downloads/${rawToken}`, req.url))
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unable to prepare download'
    const status = message === 'NOT_PURCHASED' ? 403 : 400
    return NextResponse.json({ error: message }, { status })
  }
}
