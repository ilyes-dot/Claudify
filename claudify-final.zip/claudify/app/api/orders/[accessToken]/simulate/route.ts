import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getOrderByAccessToken, markOrderPaid, markOrderFailed } from '@/lib/orders'

const CHARGILY_MODE = process.env.CHARGILY_MODE === 'live' ? 'live' : 'mock'

const schema = z.object({ outcome: z.enum(['success', 'failed']) })

export async function POST(req: NextRequest, { params }: { params: { accessToken: string } }) {
  // Hard block in live mode — this endpoint must never be reachable once
  // real payments are flowing through Chargily.
  if (CHARGILY_MODE === 'live') {
    return NextResponse.json({ error: 'The payment simulator is disabled in live mode.' }, { status: 403 })
  }

  const parsed = schema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  const order = await getOrderByAccessToken(params.accessToken)
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  }

  if (parsed.data.outcome === 'success') {
    await markOrderPaid(order.id, `mock_payment_${order.id}`)
  } else {
    await markOrderFailed(order.id, 'Simulated payment failure (mock mode).')
  }

  return NextResponse.json({ redirectTo: `/order/${order.accessToken}` })
}
