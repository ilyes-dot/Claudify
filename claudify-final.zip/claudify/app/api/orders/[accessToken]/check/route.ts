import { NextRequest, NextResponse } from 'next/server'
import { getOrderByAccessToken } from '@/lib/orders'
import { reconcileOrder } from '@/lib/sync/reconcile-order'
import { checkRateLimit, getClientIp } from '@/lib/rate-limit'

const CHARGILY_MODE = process.env.CHARGILY_MODE === 'live' ? 'live' : 'mock'

/**
 * On-demand reconciliation for a single order, triggered by the buyer's
 * "Check my order status" button. Calls the exact same reconcileOrder()
 * function the polling cron uses, so an on-demand check and a scheduled
 * sync can never disagree about how a payment gets applied — and the
 * shared idempotency key means running both back-to-back is always safe.
 */
export async function POST(req: NextRequest, { params }: { params: { accessToken: string } }) {
  const ip = getClientIp(req)
  if (!checkRateLimit(`order-check:${ip}`, 20, 5 * 60 * 1000)) {
    return NextResponse.json({ error: 'Too many requests. Please wait a moment.' }, { status: 429 })
  }

  const order = await getOrderByAccessToken(params.accessToken)
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  }

  if (CHARGILY_MODE === 'mock') {
    return NextResponse.json({
      status: order.status,
      note: 'Running in mock mode — use the simulator on your checkout page to change this order\'s status.',
    })
  }

  if (order.status !== 'awaiting_payment') {
    return NextResponse.json({ status: order.status })
  }

  try {
    await reconcileOrder(order)
    const fresh = await getOrderByAccessToken(params.accessToken)
    return NextResponse.json({ status: fresh?.status ?? order.status })
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Could not reach Chargily right now.' },
      { status: 502 }
    )
  }
}
