import { NextRequest, NextResponse } from 'next/server'
import { isSyncDue, runSyncWithRetry } from '@/lib/sync/run-sync'

/**
 * Trigger endpoint for the polling sync engine. No webhooks — this is
 * called by an external scheduler on a short, fixed interval (a free
 * service like cron-job.org or a GitHub Actions scheduled workflow hitting
 * this URL every ~15 minutes works well and costs nothing).
 *
 * The actual sync only runs when `isSyncDue()` says enough time has passed
 * per the interval configured in the admin dashboard (Settings → Sync).
 * That's what makes the interval "configurable" without needing to change
 * how often this endpoint itself is called.
 *
 * CONFIGURE: set CRON_SECRET in your server environment and point your
 * scheduler at:  POST /api/cron/sync?secret=<CRON_SECRET>
 * (or an `Authorization: Bearer <CRON_SECRET>` header — either is accepted)
 */
export async function POST(req: NextRequest) {
  return handleTrigger(req)
}

// Some free cron pingers only support GET — accept both.
export async function GET(req: NextRequest) {
  return handleTrigger(req)
}

async function handleTrigger(req: NextRequest) {
  const configuredSecret = process.env.CRON_SECRET
  if (!configuredSecret) {
    return NextResponse.json(
      { error: 'CRON_SECRET is not configured on the server — refusing to run.' },
      { status: 500 }
    )
  }

  const headerSecret = req.headers.get('authorization')?.replace(/^Bearer\s+/i, '')
  const querySecret = req.nextUrl.searchParams.get('secret')
  if (headerSecret !== configuredSecret && querySecret !== configuredSecret) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const due = await isSyncDue()
  if (!due) {
    return NextResponse.json({ ran: false, reason: 'Not due yet per the configured interval.' })
  }

  const summary = await runSyncWithRetry()
  return NextResponse.json({ ran: true, ...summary })
}
