import { redirect } from 'next/navigation'
import { getSessionAdmin, login } from '@/lib/admin/auth'
import { VerifiedSeal } from '@/components/verified-seal'

export default async function AdminLoginPage({
  searchParams,
}: {
  searchParams: { error?: string }
}) {
  const existing = await getSessionAdmin()
  if (existing) redirect('/admin')

  async function loginAction(formData: FormData) {
    'use server'
    const email = String(formData.get('email') || '')
    const password = String(formData.get('password') || '')
    const result = await login(email, password)
    if (!result.ok) {
      redirect(`/admin/login?error=${encodeURIComponent(result.error || 'Login failed')}`)
    }
    redirect('/admin')
  }

  return (
    <div className="w-full max-w-sm rounded-card border border-line-dark bg-ink-soft p-8 shadow-card-dark">
      <div className="flex items-center gap-2 text-paper">
        <VerifiedSeal size={24} />
        <span className="font-display text-lg font-semibold">Claudify Admin</span>
      </div>
      <p className="mt-2 text-sm text-paper/50">Store owner access only.</p>

      <form action={loginAction} className="mt-6 space-y-4">
        <div>
          <label htmlFor="email" className="text-xs font-medium text-paper/60">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="username"
            className="mt-1 w-full rounded-lg border border-line-dark bg-ink px-4 py-2.5 text-sm text-paper outline-none focus-visible:border-signal"
          />
        </div>
        <div>
          <label htmlFor="password" className="text-xs font-medium text-paper/60">Password</label>
          <input
            id="password"
            name="password"
            type="password"
            required
            autoComplete="current-password"
            className="mt-1 w-full rounded-lg border border-line-dark bg-ink px-4 py-2.5 text-sm text-paper outline-none focus-visible:border-signal"
          />
        </div>

        {searchParams.error && (
          <p role="alert" className="rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">
            {searchParams.error}
          </p>
        )}

        <button
          type="submit"
          className="w-full rounded-full bg-signal py-3 text-sm font-semibold text-white transition-transform hover:scale-[1.01]"
        >
          Sign in
        </button>
      </form>
    </div>
  )
}
