import { getDashboardStats, getOrderStatusBreakdown } from '@/lib/admin/services/dashboard'
import { formatDZD } from '@/lib/utils'
import { RevenueChart } from '@/components/admin/revenue-chart'
import { StatusBreakdownChart } from '@/components/admin/status-breakdown-chart'

export default async function AdminAnalyticsPage() {
  const [stats, statusBreakdown] = await Promise.all([getDashboardStats(), getOrderStatusBreakdown()])

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Analytics</h1>
      <p className="mt-1 text-sm text-ink/50">Computed live from current order data.</p>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <h2 className="font-display text-lg font-semibold text-ink">Revenue, last 30 days</h2>
          <div className="mt-4">
            <RevenueChart data={stats.revenueByDay.map((r) => ({ day: r.day.toString(), revenueDZD: r.revenueDZD }))} />
          </div>
        </div>

        <div className="rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <h2 className="font-display text-lg font-semibold text-ink">Orders by status</h2>
          <div className="mt-4">
            <StatusBreakdownChart data={statusBreakdown} />
          </div>
        </div>
      </div>

      <div className="mt-6 rounded-card border border-line bg-paper-raised shadow-card">
        <div className="border-b border-line px-6 py-4">
          <h2 className="font-display text-lg font-semibold text-ink">Best-selling products</h2>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-ink/40">
              <th className="px-6 py-3 font-medium">Product</th>
              <th className="px-6 py-3 font-medium">Units sold</th>
              <th className="px-6 py-3 font-medium">Revenue</th>
            </tr>
          </thead>
          <tbody>
            {stats.bestSellers.map((b) => (
              <tr key={b.product.id} className="border-b border-line last:border-0">
                <td className="px-6 py-3 text-ink/80">{b.product.title}</td>
                <td className="px-6 py-3 text-ink/60">{b.unitsSold}</td>
                <td className="price px-6 py-3">{formatDZD(b.unitsSold * b.product.priceDZD)}</td>
              </tr>
            ))}
            {stats.bestSellers.length === 0 && (
              <tr>
                <td colSpan={3} className="px-6 py-10 text-center text-sm text-ink/40">No sales yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
