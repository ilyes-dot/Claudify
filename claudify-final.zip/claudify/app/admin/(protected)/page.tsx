import Link from 'next/link'
import { getDashboardStats } from '@/lib/admin/services/dashboard'
import { formatDZD } from '@/lib/utils'
import { KpiCard } from '@/components/admin/kpi-card'
import { RevenueChart } from '@/components/admin/revenue-chart'

const statusTone: Record<string, string> = {
  paid: 'bg-verified/15 text-verified',
  awaiting_payment: 'bg-gold/15 text-gold',
  pending: 'bg-ink/10 text-ink/60',
  failed: 'bg-red-100 text-red-700',
  expired: 'bg-ink/10 text-ink/60',
  refunded: 'bg-ink/10 text-ink/60',
}

export default async function AdminDashboardPage() {
  const stats = await getDashboardStats()

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Dashboard</h1>
      <p className="mt-1 text-sm text-ink/50">A live snapshot of the store — nothing here is cached.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard label="Total revenue" value={formatDZD(stats.totalRevenueDZD)} sublabel={`${stats.paidOrderCount} paid orders`} />
        <KpiCard label="Conversion rate" value={`${(stats.conversionRate * 100).toFixed(1)}%`} sublabel={`${stats.totalOrderCount} checkouts started`} />
        <KpiCard label="Customers" value={stats.customerCount.toLocaleString()} />
        <KpiCard label="Open alerts" value={stats.openAlertCount.toString()} sublabel={stats.openAlertCount > 0 ? 'Needs review' : 'All clear'} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <h2 className="font-display text-lg font-semibold text-ink">Revenue, last 30 days</h2>
          <div className="mt-4">
            <RevenueChart data={stats.revenueByDay.map((r) => ({ day: r.day.toString(), revenueDZD: r.revenueDZD }))} />
          </div>
        </div>

        <div className="rounded-card border border-line bg-paper-raised p-6 shadow-card">
          <h2 className="font-display text-lg font-semibold text-ink">Best sellers</h2>
          <ul className="mt-4 space-y-3">
            {stats.bestSellers.length === 0 && <p className="text-sm text-ink/40">No sales yet.</p>}
            {stats.bestSellers.map((b) => (
              <li key={b.product.id} className="flex items-center justify-between text-sm">
                <span className="text-ink/75">{b.product.title}</span>
                <span className="font-mono text-ink/50">{b.unitsSold} sold</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-6 rounded-card border border-line bg-paper-raised shadow-card">
        <div className="flex items-center justify-between border-b border-line px-6 py-4">
          <h2 className="font-display text-lg font-semibold text-ink">Recent orders</h2>
          <Link href="/admin/orders" className="text-sm font-medium text-signal hover:text-signal-dim">
            View all &rarr;
          </Link>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-ink/40">
              <th className="px-6 py-3 font-medium">Order</th>
              <th className="px-6 py-3 font-medium">Customer</th>
              <th className="px-6 py-3 font-medium">Total</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {stats.recentOrders.map((order) => (
              <tr key={order.id} className="border-b border-line last:border-0">
                <td className="px-6 py-3">
                  <Link href={`/admin/orders/${order.id}`} className="font-mono text-xs text-signal hover:underline">
                    {order.orderNumber}
                  </Link>
                </td>
                <td className="px-6 py-3 text-ink/70">{order.customer.email}</td>
                <td className="price px-6 py-3">{formatDZD(order.totalDZD)}</td>
                <td className="px-6 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${statusTone[order.status]}`}>
                    {order.status.replace('_', ' ')}
                  </span>
                </td>
              </tr>
            ))}
            {stats.recentOrders.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-8 text-center text-sm text-ink/40">
                  No orders yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
