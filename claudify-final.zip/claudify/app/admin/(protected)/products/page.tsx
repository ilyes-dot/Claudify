import Link from 'next/link'
import { listProductsForAdmin } from '@/lib/admin/services/products'
import { formatDZD } from '@/lib/utils'

const statusTone: Record<string, string> = {
  published: 'bg-verified/15 text-verified',
  draft: 'bg-ink/10 text-ink/60',
  archived: 'bg-red-100 text-red-700',
}

export default async function AdminProductsPage() {
  const products = await listProductsForAdmin()

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Products</h1>
          <p className="mt-1 text-sm text-ink/50">{products.length} total</p>
        </div>
        <Link href="/admin/products/new" className="rounded-full bg-signal px-5 py-2.5 text-sm font-semibold text-white">
          Add product
        </Link>
      </div>

      <div className="mt-6 overflow-hidden rounded-card border border-line bg-paper-raised shadow-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-ink/40">
              <th className="px-6 py-3 font-medium">Product</th>
              <th className="px-6 py-3 font-medium">Category</th>
              <th className="px-6 py-3 font-medium">Price</th>
              <th className="px-6 py-3 font-medium">Files</th>
              <th className="px-6 py-3 font-medium">Sold</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b border-line last:border-0 hover:bg-paper/50">
                <td className="px-6 py-3">
                  <Link href={`/admin/products/${p.id}`} className="font-medium text-ink hover:text-signal">
                    {p.title}
                  </Link>
                </td>
                <td className="px-6 py-3 text-ink/60">{p.category.name}</td>
                <td className="price px-6 py-3">{formatDZD(p.priceDZD)}</td>
                <td className="px-6 py-3 text-ink/60">{p.files.length}</td>
                <td className="px-6 py-3 text-ink/60">{p._count.orderItems}</td>
                <td className="px-6 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${statusTone[p.status]}`}>
                    {p.status}
                  </span>
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-10 text-center text-sm text-ink/40">
                  No products yet — add your first one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
