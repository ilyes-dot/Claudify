import { notFound } from 'next/navigation'
import { getProductForEdit, listCategoriesForAdmin } from '@/lib/admin/services/products'
import { updateProductAction, uploadProductFileAction } from '@/lib/admin/actions/products'
import { ProductFormFields } from '@/components/admin/product-form-fields'
import { DeleteProductButton } from '@/components/admin/delete-product-button'
import { DeleteFileButton } from '@/components/admin/delete-file-button'
import { formatFileSize } from '@/lib/utils'

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const [product, categories] = await Promise.all([
    getProductForEdit(params.id),
    listCategoriesForAdmin(),
  ])
  if (!product) notFound()

  const updateWithId = updateProductAction.bind(null, product.id)
  const uploadWithId = uploadProductFileAction.bind(null, product.id)

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-ink">Edit product</h1>
        <DeleteProductButton productId={product.id} />
      </div>

      <form action={updateWithId} className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <ProductFormFields product={product} categories={categories} />
        <button
          type="submit"
          className="mt-6 rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white transition-transform hover:scale-[1.01]"
        >
          Save changes
        </button>
      </form>

      <div className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-ink">Deliverable files</h2>
        <p className="mt-1 text-sm text-ink/50">
          These are what buyers actually download after paying. On serverless hosting, uploads here
          don&rsquo;t persist across deploys — see the README for swapping in S3/R2 storage.
        </p>

        <ul className="mt-4 space-y-2">
          {product.files.map((f) => (
            <li key={f.id} className="flex items-center justify-between rounded-lg border border-line px-4 py-3 text-sm">
              <div>
                <p className="font-medium text-ink">{f.label}</p>
                <p className="text-xs text-ink/40">{f.storageKey} &middot; {formatFileSize(f.sizeBytes)}</p>
              </div>
              <DeleteFileButton productId={product.id} fileId={f.id} />
            </li>
          ))}
          {product.files.length === 0 && <p className="text-sm text-ink/40">No files yet.</p>}
        </ul>

        <form action={uploadWithId} encType="multipart/form-data" className="mt-5 flex flex-wrap items-end gap-3 border-t border-line pt-5">
          <div className="flex-1">
            <label htmlFor="label" className="text-xs font-medium text-ink/60">Label</label>
            <input
              id="label"
              name="label"
              required
              placeholder="e.g. Windows installer"
              className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
            />
          </div>
          <div>
            <label htmlFor="file" className="text-xs font-medium text-ink/60">File</label>
            <input id="file" name="file" type="file" required className="mt-1 block text-sm" />
          </div>
          <button type="submit" className="rounded-full border border-line px-4 py-2 text-sm font-medium text-ink hover:border-signal hover:text-signal">
            Upload
          </button>
        </form>
      </div>
    </div>
  )
}
