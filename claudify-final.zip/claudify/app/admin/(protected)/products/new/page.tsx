import { createProductAction } from '@/lib/admin/actions/products'
import { listCategoriesForAdmin } from '@/lib/admin/services/products'
import { ProductFormFields } from '@/components/admin/product-form-fields'

export default async function NewProductPage() {
  const categories = await listCategoriesForAdmin()

  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Add product</h1>

      <form action={createProductAction} className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <ProductFormFields categories={categories} />
        <button
          type="submit"
          className="mt-6 rounded-full bg-signal px-6 py-3 text-sm font-semibold text-white transition-transform hover:scale-[1.01]"
        >
          Create product
        </button>
      </form>
    </div>
  )
}
