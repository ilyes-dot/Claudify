import { listCustomersForAdmin } from '@/lib/admin/services/customers'
import { formatDZD } from '@/lib/utils'

export default async function AdminCustomersPage() {
  const customers = await listCustomersForAdmin()

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Customers</h1>
      <p className="mt-1 text-sm text-ink/50">{customers.length} total</p>

      <div className="mt-6 overflow-hidden rounded-card border border-line bg-paper-raised shadow-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-ink/40">
              <th className="px-6 py-3 font-medium">Email</th>
              <th className="px-6 py-3 font-medium">Orders</th>
              <th className="px-6 py-3 font-medium">Paid orders</th>
              <th className="px-6 py-3 font-medium">Total spent</th>
              <th className="px-6 py-3 font-medium">Customer since</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id} className="border-b border-line last:border-0">
                <td className="px-6 py-3 text-ink/80">{c.email}</td>
                <td className="px-6 py-3 text-ink/60">{c.orderCount}</td>
                <td className="px-6 py-3 text-ink/60">{c.paidOrderCount}</td>
                <td className="price px-6 py-3">{formatDZD(c.totalSpentDZD)}</td>
                <td className="px-6 py-3 text-ink/50">
                  {c.createdAt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                </td>
              </tr>
            ))}
            {customers.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-10 text-center text-sm text-ink/40">No customers yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
