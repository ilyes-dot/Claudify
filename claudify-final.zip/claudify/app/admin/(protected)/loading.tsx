export default function AdminLoading() {
  return (
    <div className="space-y-4">
      <div className="h-8 w-48 animate-pulse rounded-lg bg-ink/5" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-24 animate-pulse rounded-card border border-line bg-paper-raised" />
        ))}
      </div>
      <div className="h-64 animate-pulse rounded-card border border-line bg-paper-raised" />
    </div>
  )
}
