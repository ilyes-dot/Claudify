import Link from 'next/link'
import { listOrdersForAdmin } from '@/lib/admin/services/orders'
import { formatDZD } from '@/lib/utils'
import type { OrderStatus } from '@prisma/client'

const statuses: (OrderStatus | 'all')[] = ['all', 'pending', 'awaiting_payment', 'paid', 'failed', 'expired', 'refunded']

const statusTone: Record<string, string> = {
  paid: 'bg-verified/15 text-verified',
  awaiting_payment: 'bg-gold/15 text-gold',
  pending: 'bg-ink/10 text-ink/60',
  failed: 'bg-red-100 text-red-700',
  expired: 'bg-ink/10 text-ink/60',
  refunded: 'bg-ink/10 text-ink/60',
}

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: { status?: string; page?: string }
}) {
  const status = statuses.includes(searchParams.status as OrderStatus) && searchParams.status !== 'all'
    ? (searchParams.status as OrderStatus)
    : undefined
  const page = searchParams.page ? Number(searchParams.page) : 1

  const { orders, total, totalPages } = await listOrdersForAdmin({ status, page })

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Orders</h1>
      <p className="mt-1 text-sm text-ink/50">{total} total</p>

      <div className="mt-4 flex flex-wrap gap-2">
        {statuses.map((s) => (
          <Link
            key={s}
            href={s === 'all' ? '/admin/orders' : `/admin/orders?status=${s}`}
            className={`rounded-full border px-3.5 py-1.5 text-xs font-medium ${
              (s === 'all' && !status) || s === status
                ? 'border-signal bg-signal text-white'
                : 'border-line bg-paper-raised text-ink/60 hover:border-signal/50'
            }`}
          >
            {s.replace('_', ' ')}
          </Link>
        ))}
      </div>

      <div className="mt-6 overflow-hidden rounded-card border border-line bg-paper-raised shadow-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-ink/40">
              <th className="px-6 py-3 font-medium">Order</th>
              <th className="px-6 py-3 font-medium">Customer</th>
              <th className="px-6 py-3 font-medium">Items</th>
              <th className="px-6 py-3 font-medium">Total</th>
              <th className="px-6 py-3 font-medium">Placed</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b border-line last:border-0 hover:bg-paper/50">
                <td className="px-6 py-3">
                  <Link href={`/admin/orders/${order.id}`} className="font-mono text-xs text-signal hover:underline">
                    {order.orderNumber}
                  </Link>
                </td>
                <td className="px-6 py-3 text-ink/70">{order.customer.email}</td>
                <td className="px-6 py-3 text-ink/60">{order.items.length}</td>
                <td className="price px-6 py-3">{formatDZD(order.totalDZD)}</td>
                <td className="px-6 py-3 text-ink/50">
                  {order.createdAt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                </td>
                <td className="px-6 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${statusTone[order.status]}`}>
                    {order.status.replace('_', ' ')}
                  </span>
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-10 text-center text-sm text-ink/40">No orders match this filter.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex gap-2">
          {Array.from({ length: totalPages }).map((_, i) => (
            <Link
              key={i}
              href={`/admin/orders?${status ? `status=${status}&` : ''}page=${i + 1}`}
              className="rounded-lg border border-line px-3 py-1.5 text-xs text-ink/60 hover:border-signal"
            >
              {i + 1}
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
