import { notFound } from 'next/navigation'
import { getOrderForAdmin } from '@/lib/admin/services/orders'
import { formatDZD } from '@/lib/utils'
import { OrderStatusActions } from '@/components/admin/order-status-actions'

const statusTone: Record<string, string> = {
  paid: 'bg-verified/15 text-verified',
  awaiting_payment: 'bg-gold/15 text-gold',
  pending: 'bg-ink/10 text-ink/60',
  failed: 'bg-red-100 text-red-700',
  expired: 'bg-ink/10 text-ink/60',
  refunded: 'bg-ink/10 text-ink/60',
}

export default async function AdminOrderDetailPage({ params }: { params: { id: string } }) {
  const order = await getOrderForAdmin(params.id)
  if (!order) notFound()

  return (
    <div className="max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono text-xl font-semibold text-ink">{order.orderNumber}</h1>
          <p className="mt-1 text-sm text-ink/50">{order.customer.email}</p>
        </div>
        <span className={`rounded-full px-3 py-1.5 text-xs font-medium ${statusTone[order.status]}`}>
          {order.status.replace('_', ' ')}
        </span>
      </div>

      <div className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-ink">Items</h2>
        <ul className="mt-3 space-y-2">
          {order.items.map((item) => (
            <li key={item.id} className="flex items-center justify-between text-sm">
              <span className="text-ink/75">
                {item.titleSnapshot} {item.quantity > 1 && <span className="text-ink/40">&times;{item.quantity}</span>}
              </span>
              <span className="price">{formatDZD(item.unitPriceDZD * item.quantity)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-3 flex items-center justify-between border-t border-line pt-3 font-semibold text-ink">
          <span>Total</span>
          <span className="price text-lg">{formatDZD(order.totalDZD)}</span>
        </div>
      </div>

      <div className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-ink">Payment</h2>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
          <dt className="text-ink/50">Chargily checkout ID</dt>
          <dd className="font-mono text-xs text-ink/70">{order.chargilyCheckoutId ?? '—'}</dd>
          <dt className="text-ink/50">Chargily payment ID</dt>
          <dd className="font-mono text-xs text-ink/70">{order.chargilyPaymentId ?? '—'}</dd>
          <dt className="text-ink/50">Paid at</dt>
          <dd className="text-ink/70">{order.paidAt ? order.paidAt.toLocaleString() : '—'}</dd>
          {order.failureReason && (
            <>
              <dt className="text-ink/50">Failure reason</dt>
              <dd className="text-red-600">{order.failureReason}</dd>
            </>
          )}
        </dl>

        {order.paymentEvents.length > 0 && (
          <div className="mt-4 border-t border-line pt-4">
            <p className="text-xs font-medium uppercase tracking-wide text-ink/40">Reconciliation history</p>
            <ul className="mt-2 space-y-1.5">
              {order.paymentEvents.map((e) => (
                <li key={e.id} className="font-mono text-xs text-ink/50">
                  {e.appliedAt.toLocaleString()} &middot; {e.rawStatus}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-ink">Manual actions</h2>
        <p className="mt-1 text-sm text-ink/50">
          These are owner-triggered overrides only — nothing here happens automatically, and each
          requires a confirmation click. Refunding here only updates our own records; issue the
          actual refund from Chargily&rsquo;s dashboard separately.
        </p>
        <div className="mt-4">
          <OrderStatusActions orderId={order.id} status={order.status} />
        </div>
      </div>
    </div>
  )
}
