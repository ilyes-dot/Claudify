import { prisma } from '@/lib/prisma'
import { ResolveAlertButton } from '@/components/admin/resolve-alert-button'

const severityTone: Record<string, string> = {
  critical: 'bg-red-100 text-red-700',
  warning: 'bg-gold/15 text-gold',
  info: 'bg-signal/10 text-signal',
}

export default async function AdminAlertsPage() {
  const [openAlerts, resolvedAlerts] = await Promise.all([
    prisma.alert.findMany({ where: { resolved: false }, orderBy: { createdAt: 'desc' } }),
    prisma.alert.findMany({ where: { resolved: true }, orderBy: { createdAt: 'desc' }, take: 10 }),
  ])

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Alerts</h1>
      <p className="mt-1 text-sm text-ink/50">
        Raised automatically by the sync engine — high-value orders, payment failures, and repeated sync failures.
      </p>

      <div className="mt-6 space-y-3">
        {openAlerts.map((a) => (
          <div key={a.id} className="flex items-center justify-between rounded-card border border-line bg-paper-raised p-4 shadow-card">
            <div>
              <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${severityTone[a.severity]}`}>
                {a.severity}
              </span>
              <p className="mt-2 text-sm text-ink/80">{a.message}</p>
              <p className="mt-1 text-xs text-ink/40">{a.createdAt.toLocaleString()}</p>
            </div>
            <ResolveAlertButton alertId={a.id} />
          </div>
        ))}
        {openAlerts.length === 0 && (
          <div className="rounded-card border border-dashed border-line py-12 text-center text-sm text-ink/40">
            No open alerts.
          </div>
        )}
      </div>

      {resolvedAlerts.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xs font-medium uppercase tracking-wide text-ink/40">Recently resolved</h2>
          <div className="mt-3 space-y-2">
            {resolvedAlerts.map((a) => (
              <div key={a.id} className="rounded-lg border border-line bg-paper-raised/50 px-4 py-2.5 text-xs text-ink/40">
                {a.message}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
