'use client'

import { useEffect } from 'react'

export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center text-center">
      <span className="font-mono text-xs text-ink/40">
        {error.digest ? `Error ref: ${error.digest}` : 'An error occurred'}
      </span>
      <h1 className="mt-3 font-display text-xl font-semibold text-ink">Something went wrong loading this page</h1>
      <p className="mt-2 max-w-sm text-sm text-ink/60">
        Try again — if it keeps happening, check the server logs for the reference above.
      </p>
      <button onClick={reset} className="mt-6 rounded-full bg-signal px-6 py-2.5 text-sm font-semibold text-white">
        Try again
      </button>
    </div>
  )
}
