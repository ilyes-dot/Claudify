import { requireAdmin } from '@/lib/admin/auth'
import { changePasswordAction } from '@/lib/admin/actions/account'

export default async function AccountSettingsPage({
  searchParams,
}: {
  searchParams: { error?: string; success?: string }
}) {
  const admin = await requireAdmin()

  return (
    <div className="max-w-md">
      <h1 className="font-display text-2xl font-semibold text-ink">Account</h1>
      <p className="mt-1 text-sm text-ink/50">Signed in as {admin.email}</p>

      <form action={changePasswordAction} className="mt-6 space-y-4 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-ink">Change password</h2>

        {searchParams.error && (
          <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{searchParams.error}</p>
        )}
        {searchParams.success && (
          <p role="status" className="rounded-lg bg-verified/10 px-4 py-3 text-sm text-verified">
            Password updated.
          </p>
        )}

        <div>
          <label htmlFor="currentPassword" className="text-sm font-medium text-ink">Current password</label>
          <input
            id="currentPassword"
            name="currentPassword"
            type="password"
            required
            autoComplete="current-password"
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
        </div>
        <div>
          <label htmlFor="newPassword" className="text-sm font-medium text-ink">New password</label>
          <input
            id="newPassword"
            name="newPassword"
            type="password"
            required
            minLength={10}
            autoComplete="new-password"
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
        </div>
        <div>
          <label htmlFor="confirmPassword" className="text-sm font-medium text-ink">Confirm new password</label>
          <input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            required
            minLength={10}
            autoComplete="new-password"
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
        </div>

        <button type="submit" className="rounded-full bg-signal px-6 py-2.5 text-sm font-semibold text-white">
          Update password
        </button>
      </form>
    </div>
  )
}
