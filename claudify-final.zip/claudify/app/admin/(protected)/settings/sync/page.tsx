import { prisma } from '@/lib/prisma'
import { updateSyncSettingsAction } from '@/lib/admin/actions/sync-settings'
import { RunSyncNowButton } from '@/components/admin/run-sync-now-button'

const intervalLabels: Record<string, string> = {
  every_15_min: 'Every 15 minutes',
  every_30_min: 'Every 30 minutes',
  every_hour: 'Every hour',
  once_daily: 'Once per day',
}

const statusTone: Record<string, string> = {
  success: 'bg-verified/15 text-verified',
  failed: 'bg-red-100 text-red-700',
  running: 'bg-gold/15 text-gold',
  idle: 'bg-ink/10 text-ink/60',
}

export default async function SyncSettingsPage() {
  const [setting, recentLogs] = await Promise.all([
    prisma.syncSetting.upsert({ where: { id: 'singleton' }, update: {}, create: { id: 'singleton' } }),
    prisma.syncLog.findMany({ orderBy: { startedAt: 'desc' }, take: 15 }),
  ])

  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Sync settings</h1>
      <p className="mt-1 text-sm text-ink/50">
        No webhooks — payment status is reconciled by polling Chargily on the interval below.
      </p>

      <div className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-ink/40">Current status</p>
            <span className={`mt-2 inline-flex rounded-full px-3 py-1.5 text-sm font-medium ${statusTone[setting.lastStatus]}`}>
              {setting.lastStatus}
            </span>
          </div>
          <div className="text-right text-sm text-ink/50">
            <p>Last run: {setting.lastRunAt ? setting.lastRunAt.toLocaleString() : 'never'}</p>
            {setting.consecutiveFailures > 0 && (
              <p className="text-red-600">{setting.consecutiveFailures} consecutive failure(s)</p>
            )}
          </div>
        </div>
        {setting.lastError && (
          <p className="mt-3 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{setting.lastError}</p>
        )}

        <div className="mt-4 border-t border-line pt-4">
          <RunSyncNowButton />
        </div>
      </div>

      <form action={updateSyncSettingsAction} className="mt-6 rounded-card border border-line bg-paper-raised p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-ink">Configuration</h2>

        <div className="mt-4">
          <label htmlFor="interval" className="text-sm font-medium text-ink">Sync interval</label>
          <select
            id="interval"
            name="interval"
            defaultValue={setting.interval}
            className="mt-1 w-full max-w-xs rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          >
            {Object.entries(intervalLabels).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
          <p className="mt-1 text-xs text-ink/40">
            Your external scheduler can call the sync endpoint more often than this — a real sync only
            runs once this much time has passed since the last one.
          </p>
        </div>

        <label className="mt-4 flex items-center gap-2 text-sm text-ink/75">
          <input type="checkbox" name="enabled" defaultChecked={setting.enabled} className="h-4 w-4 rounded border-line" />
          Sync enabled
        </label>

        <button type="submit" className="mt-5 rounded-full bg-signal px-6 py-2.5 text-sm font-semibold text-white">
          Save settings
        </button>
      </form>

      <div className="mt-6 overflow-hidden rounded-card border border-line bg-paper-raised shadow-card">
        <div className="border-b border-line px-6 py-4">
          <h2 className="font-display text-lg font-semibold text-ink">Recent runs</h2>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-ink/40">
              <th className="px-6 py-3 font-medium">Started</th>
              <th className="px-6 py-3 font-medium">Attempt</th>
              <th className="px-6 py-3 font-medium">Checked</th>
              <th className="px-6 py-3 font-medium">Updated</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {recentLogs.map((log) => (
              <tr key={log.id} className="border-b border-line last:border-0">
                <td className="px-6 py-3 text-ink/60">{log.startedAt.toLocaleString()}</td>
                <td className="px-6 py-3 text-ink/50">{log.attempt}</td>
                <td className="px-6 py-3 text-ink/50">{log.ordersChecked}</td>
                <td className="px-6 py-3 text-ink/50">{log.ordersUpdated}</td>
                <td className="px-6 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${statusTone[log.status]}`}>
                    {log.status}
                  </span>
                </td>
              </tr>
            ))}
            {recentLogs.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-sm text-ink/40">No sync runs yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
