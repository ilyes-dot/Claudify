import { requireAdmin } from '@/lib/admin/auth'
import { prisma } from '@/lib/prisma'
import { AdminSidebar } from '@/components/admin/admin-sidebar'

export default async function AdminProtectedLayout({ children }: { children: React.ReactNode }) {
  // The real security boundary for everything under /admin — middleware.ts
  // only fast-paths the "no cookie at all" case; this is the authoritative,
  // database-checked gate.
  const admin = await requireAdmin()
  const alertCount = await prisma.alert.count({ where: { resolved: false } })

  return (
    <div className="flex min-h-screen">
      <AdminSidebar alertCount={alertCount} />
      <div className="flex-1">
        <header className="flex items-center justify-end border-b border-line-dark bg-ink px-8 py-4">
          <span className="text-sm text-paper/50">{admin.email}</span>
        </header>
        <main className="bg-paper p-8 text-ink">{children}</main>
      </div>
    </div>
  )
}
