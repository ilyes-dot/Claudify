'use client'

import { useEffect } from 'react'

export default function AdminRootError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink px-4 text-center text-paper">
      <span className="font-mono text-xs text-paper/40">
        {error.digest ? `Error ref: ${error.digest}` : 'An error occurred'}
      </span>
      <h1 className="mt-3 font-display text-xl font-semibold">Something went wrong</h1>
      <button onClick={reset} className="mt-6 rounded-full bg-signal px-6 py-2.5 text-sm font-semibold text-white">
        Try again
      </button>
    </div>
  )
}
