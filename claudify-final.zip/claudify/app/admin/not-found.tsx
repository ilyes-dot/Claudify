import Link from 'next/link'

export default function AdminNotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink px-4 text-center text-paper">
      <span className="font-mono text-sm text-paper/40">404</span>
      <h1 className="mt-3 font-display text-xl font-semibold">Page not found</h1>
      <Link href="/admin" className="mt-6 rounded-full bg-signal px-6 py-2.5 text-sm font-semibold text-white">
        Back to dashboard
      </Link>
    </div>
  )
}
