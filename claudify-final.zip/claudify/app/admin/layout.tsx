import type { Metadata } from 'next'
import { Space_Grotesk, Inter, IBM_Plex_Mono } from 'next/font/google'
import '../globals.css'

const display = Space_Grotesk({ subsets: ['latin'], weight: ['500', '600', '700'], variable: '--font-display', display: 'swap' })
const body = Inter({ subsets: ['latin'], weight: ['400', '500', '600'], variable: '--font-body', display: 'swap' })
const mono = IBM_Plex_Mono({ subsets: ['latin'], weight: ['400', '500', '600'], variable: '--font-mono', display: 'swap' })

export const metadata: Metadata = {
  title: { default: 'Claudify Admin', template: '%s — Claudify Admin' },
  robots: { index: false, follow: false, nocache: true },
}

// A second, genuinely separate root layout — this is the whole point:
// nothing from the public storefront (nav, footer, cart) is reachable from
// here, and nothing from here leaks into the storefront bundle.
export default function AdminRootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="bg-ink text-paper antialiased">{children}</body>
    </html>
  )
}
