# Claudify — Verification Checklist

I can't run this app in my own environment (no network access), so here's a concrete checklist
to work through locally. Report back anything that fails and I'll fix it immediately.

## 1. Setup
- [ ] `npm install` completes with no errors
- [ ] `.env` has `DATABASE_URL`, `DIRECT_URL`, `ADMIN_SEED_EMAIL`, `ADMIN_SEED_PASSWORD` filled in
- [ ] `npx prisma migrate dev --name init` succeeds
- [ ] `npm run db:seed` completes and prints "Admin user ready: ..."
- [ ] `npm run dev` starts with no errors, http://localhost:3000 loads

## 2. Public storefront
- [ ] Homepage loads: hero, featured products, categories, testimonials, FAQ all render
- [ ] `/products` — search box filters results as you type
- [ ] `/products` — category pills filter correctly; sort dropdown re-orders results
- [ ] Click into a product detail page — price, benefits, related products all show
- [ ] `/faq` loads and the accordion expands/collapses
- [ ] Resize the browser (or use dev tools device toolbar) at mobile (375px), tablet (768px),
      and desktop (1280px+) widths — nav collapses to a hamburger menu on mobile, grids reflow,
      nothing overflows horizontally

## 3. Cart & checkout
- [ ] "Add to cart" on a product page updates the cart icon count in the nav
- [ ] "Buy now" clears the cart, adds just that item, and jumps straight to `/checkout`
- [ ] `/cart` — quantity +/- buttons work, remove button works, subtotal updates live
- [ ] Refresh the page — cart contents persist (localStorage)
- [ ] `/checkout` — submitting with an invalid email is rejected by the browser
- [ ] Submitting a valid checkout redirects to `/checkout/mock/[token]` (mock mode)

## 4. Mock payment -> delivery
- [ ] On the mock payment page, click "Simulate successful payment"
- [ ] You land on `/order/[token]` showing status Paid, with download button(s) visible
- [ ] Clicking a download button actually downloads a file (a placeholder text file, since
      real product files haven't been uploaded yet — see below)
- [ ] Start a new checkout, this time click "Simulate failed payment" — order shows
      Payment failed status, with a "Try again" link, no download buttons
- [ ] Revisit an old paid order's URL — it still shows Paid and still offers downloads

## 5. Admin access & separation
- [ ] Visiting `/admin` while logged out redirects to `/admin/login`
- [ ] View page source on any storefront page — no admin links anywhere
- [ ] Log in at `/admin/login` with your seeded credentials
- [ ] After login, you land on `/admin` (the dashboard) — sidebar, KPIs, chart all render
- [ ] Try 6 wrong-password login attempts in a row — the 6th should show a lockout message
- [ ] `/admin/settings/account` — change your password, log out, log back in with the new one

## 6. Admin — products
- [ ] `/admin/products` lists all seeded products with correct prices/status
- [ ] Create a new product, save it — it appears in the list
- [ ] Edit an existing product's price — check the storefront product page reflects the change
      (may take a moment, or refresh)
- [ ] Upload a file on a product's edit page — it appears in the file list
- [ ] Try deleting a product that has real orders attached (from step 4 above) — it should be
      blocked with a message suggesting you archive instead
- [ ] Archive that product instead — its status updates, and it disappears from the public catalog

## 7. Admin — orders, customers, alerts, analytics
- [ ] `/admin/orders` — filter by status, pagination appears if you have >25 orders
- [ ] Open an order detail page — items, payment info, and manual action buttons all show
- [ ] Click "Mark as paid manually" — it asks for confirmation before applying (two-step)
- [ ] `/admin/customers` shows the email(s) you checked out with, with correct spend totals
- [ ] `/admin/analytics` — charts render (may be sparse with few test orders)
- [ ] `/admin/alerts` — if you created a high-value test order, an alert should appear here

## 8. Sync settings
- [ ] `/admin/settings/sync` — change the interval, save, confirm it persists on reload
- [ ] Click "Run sync now" — since CHARGILY_MODE=mock, this should complete instantly with
      0 orders checked (mock orders aren't reconciled via polling — see README)

## 9. Accessibility spot-check
- [ ] Tab through the homepage using only the keyboard — a "Skip to main content" link appears
      on the very first Tab press, and focus outlines are visible throughout
- [ ] Tab through the checkout form — every field is reachable and labeled

## 10. When you're ready for real payments
- [ ] Get real Chargily credentials, set CHARGILY_MODE=live and CHARGILY_SECRET_KEY
- [ ] Confirm the mock payment simulator is now unreachable (visiting /checkout/mock/anything
      redirects away)
- [ ] Set up the sync scheduler (see README) and confirm /admin/settings/sync shows successful
      runs after a real test purchase
