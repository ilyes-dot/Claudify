import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0B1220', // primary background — navy-black, not neutral-black
          soft: '#131C31',
          faint: '#1C2740',
        },
        paper: {
          DEFAULT: '#F4F5F7', // cool paper-white, deliberately not warm cream
          raised: '#FFFFFF',
        },
        signal: {
          DEFAULT: '#3358FF', // cobalt — the one action/accent color
          soft: '#5C7BFF',
          dim: '#1E3AC7',
        },
        gold: {
          DEFAULT: '#C89B3C', // reserved strictly for price / premium marks
          soft: '#E0BE6C',
        },
        verified: '#1E8E5A',
        line: 'rgba(11,18,32,0.10)',
        'line-dark': 'rgba(244,245,247,0.12)',
      },
      fontFamily: {
        display: ['var(--font-display)'],
        body: ['var(--font-body)'],
        mono: ['var(--font-mono)'],
      },
      borderRadius: {
        card: '14px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(11,18,32,0.06), 0 12px 32px -16px rgba(11,18,32,0.18)',
        'card-dark': '0 1px 2px rgba(0,0,0,0.3), 0 20px 40px -20px rgba(0,0,0,0.6)',
      },
      backgroundImage: {
        'seal-ring': 'repeating-conic-gradient(from 0deg, currentColor 0deg 3deg, transparent 3deg 9deg)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.5s ease-out both',
      },
    },
  },
  plugins: [],
}

export default config
