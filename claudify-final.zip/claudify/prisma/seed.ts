import { PrismaClient } from '@prisma/client'
import { hash } from '@node-rs/argon2'
import { seedCategories, seedProducts } from './seed-data'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding categories…')
  const categoryBySlug = new Map<string, string>()
  for (const c of seedCategories) {
    const category = await prisma.category.upsert({
      where: { slug: c.slug },
      update: { name: c.name, description: c.description, sortOrder: c.sortOrder },
      create: c,
    })
    categoryBySlug.set(c.slug, category.id)
  }

  console.log('Seeding products…')
  for (const p of seedProducts) {
    const categoryId = categoryBySlug.get(p.categorySlug)
    if (!categoryId) throw new Error(`Unknown category slug: ${p.categorySlug}`)

    const { files, categorySlug, ...productData } = p
    const product = await prisma.product.upsert({
      where: { slug: p.slug },
      update: { ...productData, categoryId },
      create: { ...productData, categoryId },
    })

    // Replace file rows for this product so re-running the seed stays idempotent.
    await prisma.productFile.deleteMany({ where: { productId: product.id } })
    await prisma.productFile.createMany({
      data: files.map((f, i) => ({ ...f, productId: product.id, sortOrder: i })),
    })
  }

  // Owner admin account. CHANGE THIS PASSWORD IMMEDIATELY after first login —
  // see ADMIN_SETUP.md. Reads from env so no real password is ever committed.
  const ownerEmail = process.env.ADMIN_SEED_EMAIL || 'owner@claudify.dz'
  const ownerPassword = process.env.ADMIN_SEED_PASSWORD
  if (!ownerPassword) {
    console.warn(
      '\n⚠️  ADMIN_SEED_PASSWORD not set — skipping admin user creation.\n' +
        '   Set ADMIN_SEED_EMAIL and ADMIN_SEED_PASSWORD in your .env and re-run `npm run db:seed`.\n'
    )
  } else {
    const passwordHash = await hash(ownerPassword)
    await prisma.adminUser.upsert({
      where: { email: ownerEmail },
      update: {},
      create: { email: ownerEmail, passwordHash, role: 'owner' },
    })
    console.log(`Admin user ready: ${ownerEmail}`)
  }

  // Default sync settings (Step 6).
  await prisma.syncSetting.upsert({
    where: { id: 'singleton' },
    update: {},
    create: { id: 'singleton', interval: 'every_30_min', enabled: true },
  })

  console.log('Seed complete.')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
