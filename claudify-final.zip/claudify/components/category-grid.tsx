import Link from 'next/link'
import { prisma } from '@/lib/prisma'
import { getCategories } from '@/lib/services/categories'

export async function CategoryGrid() {
  const categories = await getCategories()
  const counts = await prisma.product.groupBy({
    by: ['categoryId'],
    where: { status: 'published' },
    _count: { _all: true },
  })
  const countByCategoryId = new Map(counts.map((c) => [c.categoryId, c._count._all]))

  return (
    <section id="categories" className="bg-ink-soft/[0.02] py-20">
      <div className="container-page">
        <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">Shop by category</h2>
        <p className="mt-3 max-w-md text-ink/60">Five focused categories — no endless subfolders to dig through.</p>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => {
            const count = countByCategoryId.get(c.id) ?? 0
            return (
              <Link
                key={c.id}
                href={`/products?category=${c.slug}`}
                className="group flex flex-col justify-between rounded-card border border-line bg-paper-raised p-6 shadow-card transition-transform hover:-translate-y-1"
              >
                <div>
                  <h3 className="font-display text-lg font-semibold text-ink">{c.name}</h3>
                  <p className="mt-1.5 text-sm text-ink/55">{c.description}</p>
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <span className="font-mono text-xs text-ink/40">{count} products</span>
                  <span className="text-signal transition-transform group-hover:translate-x-1">&rarr;</span>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
