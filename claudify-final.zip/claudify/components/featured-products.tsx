import Link from 'next/link'
import { ProductCard } from '@/components/product-card'
import { getFeaturedProducts } from '@/lib/services/products'

export async function FeaturedProducts() {
  const featured = await getFeaturedProducts()

  return (
    <section className="container-page py-20">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">Featured this week</h2>
          <p className="mt-2 text-ink/60">The catalog&rsquo;s top-performing products, picked by hand.</p>
        </div>
        <Link href="/products" className="text-sm font-medium text-signal hover:text-signal-dim">
          View all products &rarr;
        </Link>
      </div>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {featured.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  )
}
