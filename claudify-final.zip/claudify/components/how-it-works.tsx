const steps = [
  {
    step: '01',
    title: 'Pick a product, pay in DA',
    body: 'Checkout with just your email and a CIB or Edahabia card via Chargily Pay. No account required.',
  },
  {
    step: '02',
    title: 'We confirm your payment',
    body: 'Claudify checks in with Chargily on a short interval to confirm your payment cleared — usually within minutes.',
  },
  {
    step: '03',
    title: 'Your file unlocks',
    body: 'Your order page updates automatically and a download link lands in your inbox. That link is yours to keep.',
  },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="container-page py-20">
      <div className="max-w-lg">
        <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">
          A checkout that actually earns your trust
        </h2>
        <p className="mt-3 text-ink/60">
          This is a real, ordered sequence — each step depends on the one before it.
        </p>
      </div>

      <ol className="mt-12 grid gap-8 sm:grid-cols-3">
        {steps.map((s, i) => (
          <li key={s.step} className="relative pl-0">
            <div className="flex items-center gap-3">
              <span className="font-mono text-sm text-signal">{s.step}</span>
              <div className="h-px flex-1 bg-line" />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold text-ink">{s.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink/60">{s.body}</p>
          </li>
        ))}
      </ol>
    </section>
  )
}
