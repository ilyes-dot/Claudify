import Link from 'next/link'
import { getCategories } from '@/lib/services/categories'
import { VerifiedSeal } from '@/components/verified-seal'

export async function Footer() {
  const categories = await getCategories()

  return (
    <footer className="border-t border-line bg-ink text-paper">
      <div className="container-page grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2 font-display text-lg font-semibold">
            <VerifiedSeal size={24} />
            Claudify
          </div>
          <p className="mt-3 max-w-xs text-sm text-paper/60">
            Digital products, delivered the moment your payment clears. Built for the Algerian market.
          </p>
        </div>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wide text-paper/40">Categories</h3>
          <ul className="mt-4 space-y-2.5">
            {categories.map((c) => (
              <li key={c.id}>
                <Link href={`/products?category=${c.slug}`} className="text-sm text-paper/70 hover:text-paper">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wide text-paper/40">Store</h3>
          <ul className="mt-4 space-y-2.5">
            <li><Link href="/products" className="text-sm text-paper/70 hover:text-paper">All products</Link></li>
            <li><Link href="/faq" className="text-sm text-paper/70 hover:text-paper">FAQ</Link></li>
            <li><Link href="/#how-it-works" className="text-sm text-paper/70 hover:text-paper">How it works</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wide text-paper/40">Trust</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-paper/70">
            <li>Secure checkout via Chargily Pay</li>
            <li>Instant, verified digital delivery</li>
            <li>Email receipt on every order</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-line-dark">
        <div className="container-page flex flex-col items-center justify-between gap-2 py-5 text-xs text-paper/40 sm:flex-row">
          <p>&copy; {new Date().getFullYear()} Claudify. All rights reserved.</p>
          <p>Prices shown in Algerian Dinar (DA).</p>
        </div>
      </div>
    </footer>
  )
}
