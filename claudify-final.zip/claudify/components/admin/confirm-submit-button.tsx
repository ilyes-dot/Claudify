'use client'

import { useState, useTransition } from 'react'

export function ConfirmSubmitButton({
  action,
  confirmLabel,
  idleLabel,
  className,
  confirmClassName,
}: {
  action: () => Promise<void> | void
  confirmLabel: string
  idleLabel: string
  className?: string
  confirmClassName?: string
}) {
  const [confirming, setConfirming] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  function handleConfirm() {
    setError(null)
    startTransition(async () => {
      try {
        await action()
        setConfirming(false)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Action failed')
      }
    })
  }

  if (confirming) {
    return (
      <div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleConfirm}
            disabled={pending}
            className={confirmClassName ?? 'rounded-full bg-red-600 px-4 py-2 text-xs font-semibold text-white disabled:opacity-60'}
          >
            {pending ? 'Working…' : confirmLabel}
          </button>
          <button type="button" onClick={() => setConfirming(false)} className="text-xs text-ink/50 hover:text-ink">
            Cancel
          </button>
        </div>
        {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
      </div>
    )
  }

  return (
    <button type="button" onClick={() => setConfirming(true)} className={className}>
      {idleLabel}
    </button>
  )
}
