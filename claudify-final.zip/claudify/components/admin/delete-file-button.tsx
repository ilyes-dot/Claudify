'use client'

import { deleteProductFileAction } from '@/lib/admin/actions/products'
import { ConfirmSubmitButton } from '@/components/admin/confirm-submit-button'

export function DeleteFileButton({ productId, fileId }: { productId: string; fileId: string }) {
  return (
    <ConfirmSubmitButton
      action={() => deleteProductFileAction(productId, fileId)}
      idleLabel="Remove"
      confirmLabel="Confirm"
      className="text-xs font-medium text-ink/40 hover:text-red-600"
      confirmClassName="rounded-full bg-red-600 px-3 py-1 text-[11px] font-semibold text-white"
    />
  )
}
