'use client'

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { formatDZD } from '@/lib/utils'

interface RevenuePoint {
  day: string
  revenueDZD: number
}

export function RevenueChart({ data }: { data: RevenuePoint[] }) {
  if (data.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-sm text-ink/40">
        No paid orders in the last 30 days yet.
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(11,18,32,0.08)" />
        <XAxis
          dataKey="day"
          tick={{ fontSize: 11, fill: 'rgba(11,18,32,0.5)' }}
          tickFormatter={(v: string) => new Date(v).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
        />
        <YAxis tick={{ fontSize: 11, fill: 'rgba(11,18,32,0.5)' }} tickFormatter={(v) => `${v / 1000}k`} />
        <Tooltip
          formatter={(value: number) => [formatDZD(value), 'Revenue']}
          labelFormatter={(v) => new Date(v).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
          contentStyle={{ borderRadius: 10, border: '1px solid rgba(11,18,32,0.1)', fontSize: 12 }}
        />
        <Line type="monotone" dataKey="revenueDZD" stroke="#3358FF" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  )
}
