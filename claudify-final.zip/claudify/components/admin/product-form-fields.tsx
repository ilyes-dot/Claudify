import type { Category, Product } from '@prisma/client'
import { CoverImageField } from '@/components/admin/cover-image-field'

export function ProductFormFields({ product, categories }: { product?: Product; categories: Category[] }) {
  return (
    <div className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="title" className="text-sm font-medium text-ink">Title</label>
          <input
            id="title"
            name="title"
            required
            defaultValue={product?.title}
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
        </div>
        <div>
          <label htmlFor="categoryId" className="text-sm font-medium text-ink">Category</label>
          <select
            id="categoryId"
            name="categoryId"
            required
            defaultValue={product?.categoryId}
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="tagline" className="text-sm font-medium text-ink">Tagline</label>
        <input
          id="tagline"
          name="tagline"
          required
          defaultValue={product?.tagline}
          className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
        />
      </div>

      <div>
        <label htmlFor="description" className="text-sm font-medium text-ink">Description</label>
        <textarea
          id="description"
          name="description"
          required
          rows={4}
          defaultValue={product?.description}
          className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
        />
      </div>

      <div>
        <label htmlFor="benefits" className="text-sm font-medium text-ink">Benefits (one per line)</label>
        <textarea
          id="benefits"
          name="benefits"
          required
          rows={4}
          defaultValue={product?.benefits.join('\n')}
          className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
        />
      </div>

      <div className="grid gap-5 sm:grid-cols-3">
        <div>
          <label htmlFor="priceDZD" className="text-sm font-medium text-ink">Price (DA)</label>
          <input
            id="priceDZD"
            name="priceDZD"
            type="number"
            required
            min={0}
            defaultValue={product?.priceDZD}
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
        </div>
        <div>
          <label htmlFor="compareAtDZD" className="text-sm font-medium text-ink">Compare-at price (optional)</label>
          <input
            id="compareAtDZD"
            name="compareAtDZD"
            type="number"
            min={0}
            defaultValue={product?.compareAtDZD ?? ''}
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
        </div>
        <div>
          <label htmlFor="status" className="text-sm font-medium text-ink">Status</label>
          <select
            id="status"
            name="status"
            defaultValue={product?.status ?? 'draft'}
            className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="archived">Archived</option>
          </select>
        </div>
      </div>

      <CoverImageField initialValue={product?.coverImage} />

      <div>
        <label htmlFor="licenseNote" className="text-sm font-medium text-ink">License note</label>
        <input
          id="licenseNote"
          name="licenseNote"
          required
          defaultValue={product?.licenseNote ?? 'Personal & commercial use unless stated otherwise.'}
          className="mt-1 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
        />
      </div>

      <label className="flex items-center gap-2 text-sm text-ink/75">
        <input type="checkbox" name="featured" defaultChecked={product?.featured} className="h-4 w-4 rounded border-line" />
        Feature on homepage
      </label>
    </div>
  )
}
