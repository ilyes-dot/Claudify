'use client'

import { deleteProductAction } from '@/lib/admin/actions/products'
import { ConfirmSubmitButton } from '@/components/admin/confirm-submit-button'

export function DeleteProductButton({ productId }: { productId: string }) {
  return (
    <ConfirmSubmitButton
      action={() => deleteProductAction(productId)}
      idleLabel="Delete product"
      confirmLabel="Confirm delete"
      className="text-sm font-medium text-red-600 hover:text-red-700"
    />
  )
}
