'use client'

import { useState } from 'react'
import Image from 'next/image'
import { uploadCoverImageAction } from '@/lib/admin/actions/products'

export function CoverImageField({ initialValue = '' }: { initialValue?: string }) {
  const [value, setValue] = useState(initialValue)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    setError(null)
    try {
      const formData = new FormData()
      formData.set('file', file)
      const url = await uploadCoverImageAction(formData)
      setValue(url)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div>
      <label className="text-sm font-medium text-ink">Cover image</label>
      <div className="mt-2 flex items-start gap-4">
        <div className="relative h-20 w-28 shrink-0 overflow-hidden rounded-lg border border-line bg-ink">
          {value && <Image src={value} alt="" fill className="object-cover" sizes="112px" />}
        </div>
        <div className="flex-1 space-y-2">
          <input
            type="text"
            name="coverImage"
            required
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="/covers/your-image.svg or an uploaded URL"
            className="w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-signal"
          />
          <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-medium text-signal hover:text-signal-dim">
            {uploading ? 'Uploading…' : 'Upload an image'}
            <input type="file" accept="image/*" className="hidden" onChange={handleFile} disabled={uploading} />
          </label>
          {error && <p className="text-xs text-red-600">{error}</p>}
          <p className="text-[11px] text-ink/40">
            On serverless hosting, uploaded files don&rsquo;t persist across deploys — see README for swapping in S3/R2.
          </p>
        </div>
      </div>
    </div>
  )
}
