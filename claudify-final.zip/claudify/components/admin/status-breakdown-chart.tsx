'use client'

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts'

const COLORS: Record<string, string> = {
  paid: '#1E8E5A',
  awaiting_payment: '#C89B3C',
  pending: '#5C7BFF',
  failed: '#DC2626',
  expired: '#94A3B8',
  refunded: '#94A3B8',
}

export function StatusBreakdownChart({ data }: { data: { status: string; count: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(11,18,32,0.08)" />
        <XAxis dataKey="status" tick={{ fontSize: 11, fill: 'rgba(11,18,32,0.5)' }} tickFormatter={(v) => v.replace('_', ' ')} />
        <YAxis tick={{ fontSize: 11, fill: 'rgba(11,18,32,0.5)' }} allowDecimals={false} />
        <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid rgba(11,18,32,0.1)', fontSize: 12 }} />
        <Bar dataKey="count" radius={[6, 6, 0, 0]}>
          {data.map((d) => (
            <Cell key={d.status} fill={COLORS[d.status] ?? '#3358FF'} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
