'use client'

import { useTransition } from 'react'
import { resolveAlertAction } from '@/lib/admin/actions/alerts'

export function ResolveAlertButton({ alertId }: { alertId: string }) {
  const [pending, startTransition] = useTransition()
  return (
    <button
      onClick={() => startTransition(() => resolveAlertAction(alertId))}
      disabled={pending}
      className="rounded-full border border-line px-3 py-1.5 text-xs font-medium text-ink/60 hover:border-signal hover:text-signal disabled:opacity-60"
    >
      {pending ? 'Resolving…' : 'Mark resolved'}
    </button>
  )
}
