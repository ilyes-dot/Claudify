'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { VerifiedSeal } from '@/components/verified-seal'

const navItems = [
  { href: '/admin', label: 'Dashboard', icon: 'grid' },
  { href: '/admin/products', label: 'Products', icon: 'box' },
  { href: '/admin/orders', label: 'Orders', icon: 'receipt' },
  { href: '/admin/customers', label: 'Customers', icon: 'users' },
  { href: '/admin/analytics', label: 'Analytics', icon: 'chart' },
  { href: '/admin/alerts', label: 'Alerts', icon: 'bell' },
  { href: '/admin/settings/sync', label: 'Sync settings', icon: 'sync' },
  { href: '/admin/settings/account', label: 'Account', icon: 'user' },
]

export function AdminSidebar({ alertCount }: { alertCount: number }) {
  const pathname = usePathname()

  return (
    <aside className="flex w-60 shrink-0 flex-col border-r border-line-dark bg-ink-soft">
      <div className="flex items-center gap-2 border-b border-line-dark px-5 py-5 text-paper">
        <VerifiedSeal size={22} />
        <span className="font-display text-sm font-semibold">Claudify Admin</span>
      </div>

      <nav className="flex-1 space-y-0.5 p-3">
        {navItems.map((item) => {
          const active = item.href === '/admin' ? pathname === '/admin' : pathname.startsWith(item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                active ? 'bg-signal/15 text-signal-soft' : 'text-paper/60 hover:bg-paper/5 hover:text-paper'
              }`}
            >
              {item.label}
              {item.href === '/admin/alerts' && alertCount > 0 && (
                <span className="rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                  {alertCount}
                </span>
              )}
            </Link>
          )
        })}
      </nav>

      <form action="/api/admin/logout" method="POST" className="border-t border-line-dark p-3">
        <button className="w-full rounded-lg px-3 py-2.5 text-left text-sm font-medium text-paper/50 hover:bg-paper/5 hover:text-paper">
          Sign out
        </button>
      </form>
    </aside>
  )
}
