'use client'

import { manuallyMarkPaidAction, manuallyMarkFailedAction, manuallyMarkRefundedAction } from '@/lib/admin/actions/orders'
import { ConfirmSubmitButton } from '@/components/admin/confirm-submit-button'

export function OrderStatusActions({ orderId, status }: { orderId: string; status: string }) {
  return (
    <div className="flex flex-wrap gap-3">
      {status !== 'paid' && (
        <ConfirmSubmitButton
          action={() => manuallyMarkPaidAction(orderId)}
          idleLabel="Mark as paid manually"
          confirmLabel="Confirm — mark paid"
          className="rounded-full border border-line px-4 py-2 text-xs font-medium text-ink hover:border-verified hover:text-verified"
        />
      )}
      {status !== 'failed' && (
        <ConfirmSubmitButton
          action={() => manuallyMarkFailedAction(orderId)}
          idleLabel="Mark as failed"
          confirmLabel="Confirm — mark failed"
          className="rounded-full border border-line px-4 py-2 text-xs font-medium text-ink hover:border-red-400 hover:text-red-600"
        />
      )}
      {status === 'paid' && (
        <ConfirmSubmitButton
          action={() => manuallyMarkRefundedAction(orderId)}
          idleLabel="Mark as refunded"
          confirmLabel="Confirm — mark refunded"
          className="rounded-full border border-line px-4 py-2 text-xs font-medium text-ink hover:border-red-400 hover:text-red-600"
        />
      )}
    </div>
  )
}
