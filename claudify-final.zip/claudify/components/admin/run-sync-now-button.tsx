'use client'

import { useTransition } from 'react'
import { runSyncNowAction } from '@/lib/admin/actions/sync-settings'

export function RunSyncNowButton() {
  const [pending, startTransition] = useTransition()
  return (
    <button
      onClick={() => startTransition(() => runSyncNowAction())}
      disabled={pending}
      className="rounded-full bg-signal px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
    >
      {pending ? 'Running…' : 'Run sync now'}
    </button>
  )
}
