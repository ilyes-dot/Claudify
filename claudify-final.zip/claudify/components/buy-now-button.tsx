'use client'

import { useRouter } from 'next/navigation'
import { useCart } from '@/components/cart-provider'

interface BuyNowButtonProps {
  productId: string
  slug: string
  title: string
  priceDZD: number
  coverImage: string
}

export function BuyNowButton(props: BuyNowButtonProps) {
  const { clear, addItem } = useCart()
  const router = useRouter()

  function handleClick() {
    clear()
    addItem(
      {
        productId: props.productId,
        slug: props.slug,
        title: props.title,
        priceDZD: props.priceDZD,
        coverImage: props.coverImage,
      },
      1
    )
    router.push('/checkout')
  }

  return (
    <button
      onClick={handleClick}
      className="mt-5 flex w-full items-center justify-center rounded-full bg-signal py-3.5 text-sm font-semibold text-white shadow-md shadow-signal/20 transition-transform hover:scale-[1.01]"
    >
      Buy now &mdash; instant delivery
    </button>
  )
}
