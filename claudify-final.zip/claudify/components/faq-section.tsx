import { FaqAccordion } from '@/components/faq-accordion'
import { faqItems } from '@/lib/data/content'

export function FaqSection() {
  return (
    <section id="faq" className="bg-ink-soft/[0.02] py-20">
      <div className="container-page grid gap-10 md:grid-cols-[0.8fr_1.2fr]">
        <div>
          <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">Questions, answered</h2>
          <p className="mt-3 max-w-sm text-ink/60">
            Can&rsquo;t find what you need? Reach out and we&rsquo;ll get back to you.
          </p>
        </div>
        <FaqAccordion items={faqItems} />
      </div>
    </section>
  )
}
