'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

export function CheckStatusButton({ accessToken }: { accessToken: string }) {
  const router = useRouter()
  const [checking, setChecking] = useState(false)

  async function handleClick() {
    setChecking(true)
    try {
      await fetch(`/api/orders/${accessToken}/check`, { method: 'POST' })
      router.refresh()
    } finally {
      setChecking(false)
    }
  }

  return (
    <button
      onClick={handleClick}
      disabled={checking}
      className="rounded-full border border-line px-5 py-2.5 text-sm font-medium text-ink hover:border-signal hover:text-signal disabled:opacity-60"
    >
      {checking ? 'Checking…' : 'Check my order status'}
    </button>
  )
}
