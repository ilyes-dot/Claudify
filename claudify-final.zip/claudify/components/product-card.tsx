import Image from 'next/image'
import Link from 'next/link'
import type { Product, Category } from '@prisma/client'
import { formatDZD } from '@/lib/utils'

type ProductWithCategory = Product & { category: Category }

export function ProductCard({ product }: { product: ProductWithCategory }) {
  const discount = product.compareAtDZD
    ? Math.round(100 - (product.priceDZD / product.compareAtDZD) * 100)
    : null

  return (
    <Link
      href={`/products/${product.slug}`}
      className="group relative flex flex-col overflow-hidden rounded-card border border-line bg-paper-raised shadow-card transition-transform duration-200 hover:-translate-y-1"
    >
      <div className="deed-corner relative aspect-[4/3] w-full overflow-hidden bg-ink">
        <Image
          src={product.coverImage}
          alt=""
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          sizes="(min-width: 1024px) 320px, (min-width: 640px) 45vw, 90vw"
        />
        {discount && (
          <span className="absolute left-3 top-3 rounded-full bg-gold px-2.5 py-1 text-xs font-semibold text-ink">
            -{discount}%
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <span className="text-xs font-medium uppercase tracking-wide text-signal">
          {product.category.name}
        </span>
        <h3 className="font-display text-base font-semibold leading-snug text-ink">
          {product.title}
        </h3>
        <p className="line-clamp-2 text-sm text-ink/60">{product.tagline}</p>

        <div className="mt-auto flex items-center justify-between pt-3">
          <div className="flex items-baseline gap-2">
            <span className="price text-lg font-semibold">{formatDZD(product.priceDZD)}</span>
            {product.compareAtDZD && (
              <span className="font-mono text-xs text-ink/35 line-through">
                {formatDZD(product.compareAtDZD)}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 text-xs text-ink/50">
            <StarIcon />
            {product.displayRating.toFixed(1)}
          </div>
        </div>
      </div>
    </Link>
  )
}

function StarIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="#C89B3C" aria-hidden>
      <path d="M8 1l1.9 4.5 4.9.4-3.7 3.2 1.1 4.8L8 11.6 3.8 13.9l1.1-4.8L1.2 5.9l4.9-.4z" />
    </svg>
  )
}
