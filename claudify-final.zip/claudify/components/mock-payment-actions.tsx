'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

export function MockPaymentActions({ accessToken }: { accessToken: string }) {
  const router = useRouter()
  const [loading, setLoading] = useState<'success' | 'failed' | null>(null)

  async function simulate(outcome: 'success' | 'failed') {
    setLoading(outcome)
    try {
      const res = await fetch(`/api/orders/${accessToken}/simulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ outcome }),
      })
      const data = await res.json()
      if (res.ok) router.push(data.redirectTo)
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="mt-8 flex flex-col gap-3 sm:flex-row">
      <button
        onClick={() => simulate('success')}
        disabled={loading !== null}
        className="flex-1 rounded-full bg-verified py-3.5 text-sm font-semibold text-white transition-transform hover:scale-[1.01] disabled:opacity-60"
      >
        {loading === 'success' ? 'Confirming…' : 'Simulate successful payment'}
      </button>
      <button
        onClick={() => simulate('failed')}
        disabled={loading !== null}
        className="flex-1 rounded-full border border-line py-3.5 text-sm font-semibold text-ink hover:border-red-400 hover:text-red-600 disabled:opacity-60"
      >
        {loading === 'failed' ? 'Processing…' : 'Simulate failed payment'}
      </button>
    </div>
  )
}
