interface VerifiedSealProps {
  size?: number
  className?: string
}

/**
 * A scalloped seal with a checkmark — Claudify's signature mark. Used small
 * as the logo, and larger as a trust indicator ("instant & secure delivery")
 * on product cards and the checkout flow.
 */
export function VerifiedSeal({ size = 32, className }: VerifiedSealProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      aria-hidden
    >
      <path
        d="M24 2 27.6 6.3 33 4.9 34.7 10.2 40.2 10.6 40.1 16.1 45 18.8 42.4 23.7 45 28.6 40.1 31.3 40.2 36.8 34.7 37.2 33 42.5 27.6 41.1 24 45.4 20.4 41.1 15 42.5 13.3 37.2 7.8 36.8 7.9 31.3 3 28.6 5.6 23.7 3 18.8 7.9 16.1 7.8 10.6 13.3 10.2 15 4.9 20.4 6.3Z"
        fill="currentColor"
        className="text-signal"
      />
      <path
        d="M16.5 24.5l5 5 10-10.5"
        stroke="white"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
