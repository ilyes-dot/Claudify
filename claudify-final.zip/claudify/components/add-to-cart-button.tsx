'use client'

import { useState } from 'react'
import { useCart } from '@/components/cart-provider'

interface AddToCartButtonProps {
  productId: string
  slug: string
  title: string
  priceDZD: number
  coverImage: string
}

export function AddToCartButton(props: AddToCartButtonProps) {
  const { addItem } = useCart()
  const [added, setAdded] = useState(false)

  function handleClick() {
    addItem(props, 1)
    setAdded(true)
    setTimeout(() => setAdded(false), 1600)
  }

  return (
    <button
      onClick={handleClick}
      className="mt-3 flex w-full items-center justify-center rounded-full border border-line bg-paper-raised py-3 text-sm font-semibold text-ink transition-colors hover:border-signal hover:text-signal"
    >
      {added ? 'Added to cart' : 'Add to cart'}
    </button>
  )
}
