import Link from 'next/link'
import { VerifiedSeal } from '@/components/verified-seal'

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-ink text-paper">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 -top-40 h-[520px] w-[520px] rounded-full bg-signal/20 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 bottom-0 h-[360px] w-[360px] rounded-full bg-gold/10 blur-3xl"
      />

      <div className="container-page relative grid gap-12 py-20 md:grid-cols-2 md:items-center md:py-28">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-line-dark px-3 py-1 text-xs font-medium text-paper/70">
            <VerifiedSeal size={16} />
            Instant, verified delivery
          </span>

          <h1 className="mt-6 font-display text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl">
            Buy the file.<br />
            Get the file.<br />
            <span className="text-signal-soft">Nothing in between.</span>
          </h1>

          <p className="mt-6 max-w-md text-lg text-paper/65">
            Claudify sells templates, courses, guides and tools to the Algerian market —
            paid securely in DA, unlocked the moment your payment is confirmed.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link
              href="/products"
              className="rounded-full bg-signal px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-signal/20 transition-transform hover:scale-[1.03]"
            >
              Browse the catalog
            </Link>
            <Link
              href="/#how-it-works"
              className="text-sm font-medium text-paper/70 underline decoration-paper/30 underline-offset-4 hover:text-paper"
            >
              See how delivery works
            </Link>
          </div>

          <dl className="mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-line-dark pt-6">
            <div>
              <dt className="font-mono text-2xl font-semibold text-paper">4,600+</dt>
              <dd className="text-xs text-paper/50">Orders delivered</dd>
            </div>
            <div>
              <dt className="font-mono text-2xl font-semibold text-paper">4.8/5</dt>
              <dd className="text-xs text-paper/50">Average rating</dd>
            </div>
            <div>
              <dt className="font-mono text-2xl font-semibold text-paper">&lt;5 min</dt>
              <dd className="text-xs text-paper/50">Typical delivery time</dd>
            </div>
          </dl>
        </div>

        {/* Signature visual: a mock "digital deed" receipt card */}
        <div className="relative mx-auto w-full max-w-sm">
          <div className="deed-corner rounded-card border border-line-dark bg-ink-soft p-6 shadow-card-dark">
            <div className="flex items-center justify-between border-b border-line-dark pb-4">
              <span className="font-mono text-xs text-paper/45">ORDER #CLDF-88214</span>
              <span className="flex items-center gap-1.5 rounded-full bg-verified/15 px-2.5 py-1 text-xs font-medium text-verified">
                <span className="h-1.5 w-1.5 rounded-full bg-verified" /> Paid
              </span>
            </div>

            <div className="flex items-center gap-3 py-5">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-signal/15 font-display text-sm font-semibold text-signal-soft">
                RD
              </div>
              <div>
                <p className="text-sm font-medium text-paper">React Admin Dashboard UI Kit</p>
                <p className="font-mono text-xs text-paper/45">18 MB &middot; ZIP</p>
              </div>
            </div>

            <div className="flex items-center justify-between rounded-lg bg-signal/10 px-4 py-3">
              <span className="text-sm font-medium text-signal-soft">Download unlocked</span>
              <VerifiedSeal size={22} />
            </div>

            <p className="mt-4 text-center font-mono text-[11px] text-paper/35">
              Confirmed via Chargily Pay &middot; receipt sent by email
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
