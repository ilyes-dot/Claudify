'use client'

import Link from 'next/link'
import { useState } from 'react'
import { VerifiedSeal } from '@/components/verified-seal'
import { useCart } from '@/components/cart-provider'

const links = [
  { href: '/products', label: 'Catalog' },
  { href: '/#categories', label: 'Categories' },
  { href: '/#how-it-works', label: 'How it works' },
  { href: '/faq', label: 'FAQ' },
]

export function NavBar() {
  const [open, setOpen] = useState(false)
  const { totalCount } = useCart()

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-paper/90 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-display text-lg font-semibold tracking-tight">
          <VerifiedSeal size={26} />
          Claudify
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-ink/70 transition-colors hover:text-ink"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Link href="/cart" className="relative flex h-10 w-10 items-center justify-center rounded-full border border-line hover:border-signal" aria-label={`Cart, ${totalCount} item${totalCount === 1 ? '' : 's'}`}>
            <CartIcon />
            {totalCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-signal text-[10px] font-semibold text-white">
                {totalCount}
              </span>
            )}
          </Link>
          <Link
            href="/products"
            className="rounded-full bg-signal px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition-transform hover:scale-[1.03] hover:bg-signal-dim"
          >
            Browse products
          </Link>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <Link href="/cart" className="relative flex h-10 w-10 items-center justify-center rounded-full border border-line" aria-label={`Cart, ${totalCount} item${totalCount === 1 ? '' : 's'}`}>
            <CartIcon />
            {totalCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-signal text-[10px] font-semibold text-white">
                {totalCount}
              </span>
            )}
          </Link>
          <button
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            <span className="sr-only">Toggle navigation</span>
            {open ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-line bg-paper md:hidden">
          <div className="container-page flex flex-col gap-1 py-3">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-base font-medium text-ink/80 hover:bg-ink/5"
              >
                {l.label}
              </Link>
            ))}
            <Link
              href="/products"
              onClick={() => setOpen(false)}
              className="mt-2 rounded-full bg-signal px-5 py-3 text-center text-sm font-semibold text-white"
            >
              Browse products
            </Link>
          </div>
        </nav>
      )}
    </header>
  )
}

function CartIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 18 18" fill="none" aria-hidden>
      <path
        d="M2 2h1.6l.6 3M4.2 5H15l-1.3 6.2a1.5 1.5 0 01-1.47 1.2H6.3a1.5 1.5 0 01-1.47-1.2L3.6 5z"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <circle cx="7" cy="15.5" r="1" fill="currentColor" />
      <circle cx="12" cy="15.5" r="1" fill="currentColor" />
    </svg>
  )
}

function MenuIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden>
      <path d="M2 4.5h14M2 9h14M2 13.5h14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}
function CloseIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden>
      <path d="M2 2l12 12M14 2L2 14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}
