import Link from 'next/link'

export function CtaSection() {
  return (
    <section className="container-page pb-24">
      <div className="deed-corner relative overflow-hidden rounded-card bg-ink px-8 py-14 text-center text-paper sm:px-16">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-signal/25 blur-3xl"
        />
        <h2 className="relative font-display text-3xl font-semibold tracking-tight sm:text-4xl">
          Find your next tool in under a minute
        </h2>
        <p className="relative mx-auto mt-3 max-w-md text-paper/65">
          Eight categories, one secure checkout, delivery the moment your payment clears.
        </p>
        <Link
          href="/products"
          className="relative mt-8 inline-flex rounded-full bg-signal px-8 py-3.5 text-sm font-semibold text-white shadow-lg shadow-signal/30 transition-transform hover:scale-[1.03]"
        >
          Browse the catalog
        </Link>
      </div>
    </section>
  )
}
