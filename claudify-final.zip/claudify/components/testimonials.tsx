import { testimonials } from '@/lib/data/content'

export function Testimonials() {
  return (
    <section className="container-page py-20">
      <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">Trusted by buyers across Algeria</h2>

      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {testimonials.map((t) => (
          <figure
            key={t.id}
            className="flex flex-col justify-between rounded-card border border-line bg-paper-raised p-6 shadow-card"
          >
            <blockquote className="text-sm leading-relaxed text-ink/75">&ldquo;{t.quote}&rdquo;</blockquote>
            <figcaption className="mt-6 flex items-center gap-3 border-t border-line pt-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-signal/10 font-display text-xs font-semibold text-signal">
                {t.name.split(' ').map((p) => p[0]).join('')}
              </div>
              <div>
                <p className="text-sm font-medium text-ink">{t.name}</p>
                <p className="text-xs text-ink/50">{t.role}</p>
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  )
}
