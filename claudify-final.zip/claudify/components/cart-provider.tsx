'use client'

import { createContext, useContext, useEffect, useMemo, useState, ReactNode } from 'react'

export interface CartItem {
  productId: string
  slug: string
  title: string
  priceDZD: number
  coverImage: string
  quantity: number
}

interface CartContextValue {
  items: CartItem[]
  addItem: (item: Omit<CartItem, 'quantity'>, quantity?: number) => void
  removeItem: (productId: string) => void
  setQuantity: (productId: string, quantity: number) => void
  clear: () => void
  totalDZD: number
  totalCount: number
}

const CartContext = createContext<CartContextValue | null>(null)
const STORAGE_KEY = 'claudify_cart_v1'
const MAX_QUANTITY = 5

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [hydrated, setHydrated] = useState(false)

  // Hydrate from localStorage once on mount (guarded — this must never run
  // during SSR, where `window` doesn't exist).
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY)
      if (raw) setItems(JSON.parse(raw))
    } catch {
      // Corrupt or inaccessible storage — start with an empty cart rather than crash.
    } finally {
      setHydrated(true)
    }
  }, [])

  useEffect(() => {
    if (!hydrated) return
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  }, [items, hydrated])

  const addItem: CartContextValue['addItem'] = (item, quantity = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.productId === item.productId)
      if (existing) {
        return prev.map((i) =>
          i.productId === item.productId
            ? { ...i, quantity: Math.min(MAX_QUANTITY, i.quantity + quantity) }
            : i
        )
      }
      return [...prev, { ...item, quantity: Math.min(MAX_QUANTITY, quantity) }]
    })
  }

  const removeItem = (productId: string) => {
    setItems((prev) => prev.filter((i) => i.productId !== productId))
  }

  const setQuantity = (productId: string, quantity: number) => {
    setItems((prev) =>
      prev.map((i) =>
        i.productId === productId ? { ...i, quantity: Math.max(1, Math.min(MAX_QUANTITY, quantity)) } : i
      )
    )
  }

  const clear = () => setItems([])

  const { totalDZD, totalCount } = useMemo(
    () => ({
      totalDZD: items.reduce((sum, i) => sum + i.priceDZD * i.quantity, 0),
      totalCount: items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    [items]
  )

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, setQuantity, clear, totalDZD, totalCount }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within a CartProvider')
  return ctx
}
