'use client'

import { useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import type { Product, Category } from '@prisma/client'
import { ProductCard } from '@/components/product-card'

type ProductWithCategory = Product & { category: Category }

type SortKey = 'popular' | 'price-asc' | 'price-desc' | 'rating'

const sortOptions: { value: SortKey; label: string }[] = [
  { value: 'popular', label: 'Most popular' },
  { value: 'rating', label: 'Highest rated' },
  { value: 'price-asc', label: 'Price: low to high' },
  { value: 'price-desc', label: 'Price: high to low' },
]

export function ProductCatalog({
  products,
  categories,
}: {
  products: ProductWithCategory[]
  categories: Category[]
}) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [query, setQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState<string | null>(
    searchParams.get('category')
  )
  const [sort, setSort] = useState<SortKey>('popular')

  function selectCategory(slug: string | null) {
    setActiveCategory(slug)
    const params = new URLSearchParams(searchParams.toString())
    if (slug) params.set('category', slug)
    else params.delete('category')
    router.replace(`/products${params.toString() ? `?${params}` : ''}`, { scroll: false })
  }

  const filtered = useMemo(() => {
    let list = products
    if (activeCategory) list = list.filter((p) => p.category.slug === activeCategory)
    if (query.trim()) {
      const q = query.trim().toLowerCase()
      list = list.filter(
        (p) => p.title.toLowerCase().includes(q) || p.tagline.toLowerCase().includes(q)
      )
    }
    const sorted = [...list]
    switch (sort) {
      case 'price-asc':
        sorted.sort((a, b) => a.priceDZD - b.priceDZD)
        break
      case 'price-desc':
        sorted.sort((a, b) => b.priceDZD - a.priceDZD)
        break
      case 'rating':
        sorted.sort((a, b) => b.displayRating - a.displayRating)
        break
      default:
        sorted.sort((a, b) => b.displayReviewCount - a.displayReviewCount)
    }
    return sorted
  }, [products, activeCategory, query, sort])

  return (
    <div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <SearchIcon className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink/35" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products…"
            aria-label="Search products"
            className="w-full rounded-full border border-line bg-paper-raised py-2.5 pl-10 pr-4 text-sm outline-none placeholder:text-ink/35 focus-visible:border-signal"
          />
        </div>

        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as SortKey)}
          aria-label="Sort products"
          className="w-full rounded-full border border-line bg-paper-raised px-4 py-2.5 text-sm outline-none focus-visible:border-signal sm:w-auto"
        >
          {sortOptions.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        <button
          onClick={() => selectCategory(null)}
          className={pillClass(activeCategory === null)}
        >
          All
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => selectCategory(c.slug)}
            className={pillClass(activeCategory === c.slug)}
          >
            {c.name}
          </button>
        ))}
      </div>

      <p className="mt-6 text-sm text-ink/50">
        {filtered.length} product{filtered.length === 1 ? '' : 's'}
      </p>

      {filtered.length > 0 ? (
        <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      ) : (
        <div className="mt-16 flex flex-col items-center gap-2 rounded-card border border-dashed border-line py-16 text-center">
          <p className="font-medium text-ink">No products match that search</p>
          <p className="text-sm text-ink/50">Try a different keyword or clear the category filter.</p>
        </div>
      )}
    </div>
  )
}

function pillClass(active: boolean) {
  return `rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
    active
      ? 'border-signal bg-signal text-white'
      : 'border-line bg-paper-raised text-ink/70 hover:border-signal/50'
  }`
}

function SearchIcon({ className }: { className?: string }) {
  return (
    <svg width="15" height="15" viewBox="0 0 16 16" fill="none" className={className} aria-hidden>
      <circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.4" />
      <path d="M11 11l3.5 3.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  )
}
