/**
 * Standalone sync trigger for self-hosted deployments (a VPS, for example),
 * as an alternative to the HTTP trigger at /api/cron/sync. Wire this into
 * system cron, e.g. a crontab entry like:
 *
 *   /15 * * * *  cd /path/to/claudify && npm run sync:run >> sync.log 2>&1
 *
 * Same self-throttling behavior as the HTTP route: run this as often as
 * you like (every 15 minutes is a sensible default), and it will only
 * perform a real sync when the admin-configured interval says it's due.
 * Pass --force to bypass that check (useful for manually testing).
 */
import { isSyncDue, runSyncWithRetry } from '../lib/sync/run-sync'
import { prisma } from '../lib/prisma'

async function main() {
  const force = process.argv.includes('--force')

  const due = force || (await isSyncDue())
  if (!due) {
    console.log('[sync] Not due yet — skipping.')
    return
  }

  const summary = await runSyncWithRetry()
  console.log('[sync] Finished:', summary)

  if (summary.status === 'failed') {
    process.exitCode = 1
  }
}

main()
  .catch((err) => {
    console.error('[sync] Fatal error:', err)
    process.exitCode = 1
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
