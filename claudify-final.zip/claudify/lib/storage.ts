import { createReadStream, existsSync, statSync } from 'fs'
import { join } from 'path'
import { Readable } from 'stream'

/**
 * Every digital file lives outside the web root and is only ever reached
 * through the signed download-token flow (lib/download-tokens.ts) — never
 * a public URL. This module is the one place that knows *how* files are
 * stored, so swapping providers later never touches the download route.
 *
 * Dev/low-cost default: local filesystem, under a git-ignored directory.
 * CONFIGURE FOR PRODUCTION: replace with an S3-compatible adapter (AWS S3,
 * Cloudflare R2, Backblaze B2 — all inexpensive and all speak the S3 API)
 * once you're ready to deploy. Swap only the two functions below; nothing
 * else in the app needs to change.
 */

const LOCAL_STORAGE_ROOT = join(process.cwd(), 'private-storage')

export interface StoredFile {
  stream: ReadableStream
  sizeBytes: number
}

export async function getFileStream(storageKey: string): Promise<StoredFile> {
  const fullPath = join(LOCAL_STORAGE_ROOT, storageKey)

  // Defends against a storageKey containing `..` ever escaping the storage root.
  if (!fullPath.startsWith(LOCAL_STORAGE_ROOT)) {
    throw new Error('Invalid storage key')
  }
  if (!existsSync(fullPath)) {
    throw new Error(
      `File not found for storageKey "${storageKey}". Add the real file under private-storage/, ` +
        `or configure an S3-compatible adapter in lib/storage.ts for production.`
    )
  }

  const { size } = statSync(fullPath)
  const nodeStream = createReadStream(fullPath)
  return { stream: Readable.toWeb(nodeStream) as ReadableStream, sizeBytes: size }
}

export async function fileExists(storageKey: string): Promise<boolean> {
  return existsSync(join(LOCAL_STORAGE_ROOT, storageKey))
}
