// Product/Category/Order types now come from the generated Prisma client
// (import from '@prisma/client'). This file only holds types for content
// that isn't database-backed.

export interface Testimonial {
  id: string
  name: string
  role: string
  quote: string
  productSlug?: string
}

export interface FaqItem {
  question: string
  answer: string
}
