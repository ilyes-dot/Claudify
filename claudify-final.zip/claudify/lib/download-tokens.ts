import { randomBytes, createHash } from 'crypto'
import { prisma } from '@/lib/prisma'

const TOKEN_TTL_MS = 10 * 60 * 1000 // 10 minutes — long enough to complete a download, short enough to limit exposure
const MAX_USES = 1

function hashToken(rawToken: string): string {
  return createHash('sha256').update(rawToken).digest('hex')
}

/**
 * Verifies that `productFileId` actually belongs to a product the given
 * order paid for. This is the ownership check that stands between "I know
 * an order's access token" and "I can download any file in the catalog".
 */
async function assertOrderOwnsFile(orderId: string, productFileId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: true },
  })
  if (!order || order.status !== 'paid') {
    throw new Error('ORDER_NOT_PAID')
  }

  const file = await prisma.productFile.findUnique({ where: { id: productFileId } })
  if (!file) throw new Error('FILE_NOT_FOUND')

  const ownsProduct = order.items.some((item) => item.productId === file.productId)
  if (!ownsProduct) throw new Error('NOT_PURCHASED')

  return file
}

/**
 * Mints a fresh, single-use download token for one file, after verifying
 * the order actually paid for the product it belongs to. Called only at the
 * moment a paying customer clicks "Download" — never eagerly at payment
 * time — so there's nothing sensitive to store or redisplay later.
 */
export async function mintDownloadToken(orderId: string, productFileId: string): Promise<string> {
  await assertOrderOwnsFile(orderId, productFileId)

  const rawToken = randomBytes(32).toString('hex')
  await prisma.downloadToken.create({
    data: {
      orderId,
      productFileId,
      tokenHash: hashToken(rawToken),
      maxUses: MAX_USES,
      expiresAt: new Date(Date.now() + TOKEN_TTL_MS),
    },
  })
  return rawToken
}

interface ConsumeResult {
  storageKey: string
  fileName: string
}

/**
 * Validates a raw token from a download URL, marks it used, and returns
 * the file it grants access to. Throws on invalid, expired, or
 * already-consumed tokens — the download route turns that into a 403/410.
 */
export async function verifyAndConsumeToken(rawToken: string): Promise<ConsumeResult> {
  const tokenHash = hashToken(rawToken)

  return prisma.$transaction(async (tx) => {
    const record = await tx.downloadToken.findUnique({
      where: { tokenHash },
      include: { productFile: true },
    })
    if (!record) throw new Error('INVALID_TOKEN')
    if (record.expiresAt < new Date()) throw new Error('EXPIRED_TOKEN')
    if (record.usedCount >= record.maxUses) throw new Error('TOKEN_ALREADY_USED')

    await tx.downloadToken.update({
      where: { id: record.id },
      data: { usedCount: { increment: 1 } },
    })

    return { storageKey: record.productFile.storageKey, fileName: record.productFile.label }
  })
}
