import { prisma } from '@/lib/prisma'
import { reconcileOrder } from '@/lib/sync/reconcile-order'
import type { SyncInterval } from '@prisma/client'

const SINGLETON_ID = 'singleton'
const MAX_ATTEMPTS = 3
const RETRY_BACKOFF_MS = 5_000 // simple fixed backoff between in-cycle retries — enough for transient network blips
const CONSECUTIVE_FAILURE_ALERT_THRESHOLD = 3

function intervalToMs(interval: SyncInterval): number {
  switch (interval) {
    case 'every_15_min':
      return 15 * 60 * 1000
    case 'every_30_min':
      return 30 * 60 * 1000
    case 'every_hour':
      return 60 * 60 * 1000
    case 'once_daily':
      return 24 * 60 * 60 * 1000
  }
}

async function getOrCreateSyncSetting() {
  return prisma.syncSetting.upsert({
    where: { id: SINGLETON_ID },
    update: {},
    create: { id: SINGLETON_ID },
  })
}

/**
 * True once enough time has passed since the last run, per the interval
 * configured in the admin dashboard. This is what lets a single
 * fixed-frequency external trigger (e.g. a free 15-minute cron ping)
 * behave like an admin-configurable scheduler: the trigger can fire often,
 * but a real sync only happens when this says it's due.
 */
export async function isSyncDue(): Promise<boolean> {
  const setting = await getOrCreateSyncSetting()
  if (!setting.enabled) return false
  if (!setting.lastRunAt) return true
  return Date.now() - setting.lastRunAt.getTime() >= intervalToMs(setting.interval)
}

interface CycleResult {
  ordersChecked: number
  ordersUpdated: number
}

async function runCycleOnce(): Promise<CycleResult> {
  const orders = await prisma.order.findMany({ where: { status: 'awaiting_payment' } })

  let ordersUpdated = 0
  for (const order of orders) {
    try {
      const outcome = await reconcileOrder(order)
      if (outcome === 'updated') ordersUpdated++

      if (outcome === 'updated') {
        const fresh = await prisma.order.findUnique({ where: { id: order.id } })
        if (fresh?.status === 'failed') {
          await prisma.alert.create({
            data: {
              severity: 'warning',
              type: 'payment_failed',
              message: `Order ${fresh.orderNumber} payment failed or was canceled.`,
              relatedOrderId: fresh.id,
            },
          })
        }
      }
    } catch (err) {
      // One order's reconciliation failing (e.g. a single bad Chargily
      // response) must not abort the whole cycle — every other order still
      // gets checked. This is logged on the cycle's error message and will
      // simply be retried on the next tick since the order stays
      // `awaiting_payment` either way.
      console.error(`[sync] Failed to reconcile order ${order.id}:`, err)
    }
  }

  return { ordersChecked: orders.length, ordersUpdated }
}

export interface SyncRunSummary {
  status: 'success' | 'failed'
  attempt: number
  ordersChecked: number
  ordersUpdated: number
  errorMessage?: string
}

/**
 * Runs one full sync cycle with automatic retry on failure (simple fixed
 * backoff, up to MAX_ATTEMPTS). Every attempt is recorded as its own
 * SyncLog row so failures are visible, not just the eventual outcome.
 */
export async function runSyncWithRetry(): Promise<SyncRunSummary> {
  await prisma.syncSetting.upsert({
    where: { id: SINGLETON_ID },
    update: { lastStatus: 'running' },
    create: { id: SINGLETON_ID, lastStatus: 'running' },
  })

  let lastError: string | undefined

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const log = await prisma.syncLog.create({
      data: { status: 'running', attempt },
    })

    try {
      const { ordersChecked, ordersUpdated } = await runCycleOnce()

      await prisma.syncLog.update({
        where: { id: log.id },
        data: { status: 'success', finishedAt: new Date(), ordersChecked, ordersUpdated },
      })
      await prisma.syncSetting.update({
        where: { id: SINGLETON_ID },
        data: { lastRunAt: new Date(), lastStatus: 'success', lastError: null, consecutiveFailures: 0 },
      })

      return { status: 'success', attempt, ordersChecked, ordersUpdated }
    } catch (err) {
      lastError = err instanceof Error ? err.message : 'Unknown sync error'
      await prisma.syncLog.update({
        where: { id: log.id },
        data: { status: 'failed', finishedAt: new Date(), errorMessage: lastError },
      })

      if (attempt < MAX_ATTEMPTS) {
        await new Promise((resolve) => setTimeout(resolve, RETRY_BACKOFF_MS))
      }
    }
  }

  // Every attempt failed.
  const setting = await prisma.syncSetting.update({
    where: { id: SINGLETON_ID },
    data: {
      lastRunAt: new Date(),
      lastStatus: 'failed',
      lastError,
      consecutiveFailures: { increment: 1 },
    },
  })

  if (setting.consecutiveFailures >= CONSECUTIVE_FAILURE_ALERT_THRESHOLD) {
    await prisma.alert.create({
      data: {
        severity: 'critical',
        type: 'sync_failed',
        message: `Order sync has failed ${setting.consecutiveFailures} times in a row. Last error: ${lastError}`,
      },
    })
  }

  return { status: 'failed', attempt: MAX_ATTEMPTS, ordersChecked: 0, ordersUpdated: 0, errorMessage: lastError }
}
