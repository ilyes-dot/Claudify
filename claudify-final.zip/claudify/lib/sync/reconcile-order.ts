import { prisma } from '@/lib/prisma'
import { getCheckoutStatus } from '@/lib/chargily'
import { markOrderPaid, markOrderFailed } from '@/lib/orders'
import type { Order } from '@prisma/client'

export type ReconcileOutcome = 'unchanged' | 'updated' | 'skipped_duplicate'

/**
 * Reconciles one order against Chargily's current checkout status.
 *
 * Idempotency: Chargily's polling API doesn't hand out a distinct "event
 * id" the way a webhook payload would, so we build one ourselves from
 * (checkoutId, status, updatedAt). A poll that sees no change produces the
 * same key every time and is skipped via PaymentEvent's unique constraint
 * — so re-running this function (a retried cron tick, an on-demand check
 * right after a scheduled one) can never double-apply the same payment.
 *
 * Future webhooks: if you later add a Chargily webhook endpoint, it should
 * call markOrderPaid()/markOrderFailed() from lib/orders.ts directly (using
 * the real event id Chargily sends) rather than duplicating this function's
 * logic — polling and webhooks can then coexist, each just a different way
 * of deciding *when* to apply the same underlying state change.
 */
export async function reconcileOrder(order: Order): Promise<ReconcileOutcome> {
  if (!order.chargilyCheckoutId) return 'unchanged'

  const result = await getCheckoutStatus(order.chargilyCheckoutId)
  const providerEventId = `${result.providerCheckoutId}:${result.status}:${result.updatedAt}`

  try {
    await prisma.paymentEvent.create({
      data: {
        orderId: order.id,
        providerEventId,
        rawStatus: result.status,
      },
    })
  } catch (err) {
    // Unique constraint violation on providerEventId = we've already
    // applied this exact event. Nothing new happened since the last check.
    return 'skipped_duplicate'
  }

  switch (result.status) {
    case 'paid':
      await markOrderPaid(order.id)
      return 'updated'
    case 'failed':
    case 'canceled':
      await markOrderFailed(order.id, `Chargily reported status: ${result.status}`)
      return 'updated'
    case 'pending':
    case 'processing':
    default:
      return 'unchanged'
  }
}
