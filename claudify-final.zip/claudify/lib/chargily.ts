import type { Order } from '@prisma/client'

/**
 * Chargily Pay integration point.
 *
 * Endpoint shapes below are taken directly from Chargily's official docs
 * (https://dev.chargily.com/pay-v2/api-reference/checkouts, fetched while
 * building this), not guessed. What's still unverified against your real
 * account is anything account-specific — fee allocation defaults, which
 * payment methods are enabled, etc. — so test thoroughly in Chargily's test
 * mode before flipping CHARGILY_MODE to "live".
 *
 * CONFIGURE THIS: set these server-side env vars once you have credentials:
 *   CHARGILY_MODE=live
 *   CHARGILY_SECRET_KEY=test_sk_...   (or a live sk_... key when you're ready)
 *   APP_URL=https://your-real-domain.example
 * The test/live Chargily API base URL is chosen automatically from whether
 * your secret key starts with "test_sk_" — no separate flag needed.
 */

const CHARGILY_MODE = process.env.CHARGILY_MODE === 'live' ? 'live' : 'mock'
const CHARGILY_SECRET_KEY = process.env.CHARGILY_SECRET_KEY || ''
const APP_URL = process.env.APP_URL || 'http://localhost:3000'

const CHARGILY_BASE_URL = CHARGILY_SECRET_KEY.startsWith('test_sk_')
  ? 'https://pay.chargily.net/test/api/v2'
  : 'https://pay.chargily.net/api/v2'

export interface CheckoutSessionResult {
  checkoutUrl: string
  providerCheckoutId: string
}

export async function createCheckoutSession(order: Order): Promise<CheckoutSessionResult> {
  if (CHARGILY_MODE === 'mock') {
    return createCheckoutSessionMock(order)
  }
  return createCheckoutSessionLive(order)
}

export type ChargilyCheckoutStatus = 'pending' | 'processing' | 'paid' | 'failed' | 'canceled'

export interface CheckoutStatusResult {
  providerCheckoutId: string
  status: ChargilyCheckoutStatus
  updatedAt: number // Chargily's unix timestamp — used to build a stable idempotency key
}

export async function getCheckoutStatus(providerCheckoutId: string): Promise<CheckoutStatusResult> {
  if (CHARGILY_MODE === 'mock') {
    throw new Error(
      'getCheckoutStatus is not meaningful in mock mode — mock orders are resolved directly ' +
        'via the /checkout/mock simulator, not by polling.'
    )
  }
  return getCheckoutStatusLive(providerCheckoutId)
}

// ---------- Mock mode (default until you configure real credentials) ----------

async function createCheckoutSessionMock(order: Order): Promise<CheckoutSessionResult> {
  const providerCheckoutId = `mock_${order.id}`
  return {
    providerCheckoutId,
    // Sends the buyer to our own simulated payment page instead of Chargily's
    // real hosted checkout — lets you test the full purchase → delivery flow
    // today, with zero real credentials.
    checkoutUrl: `/checkout/mock/${order.accessToken}`,
  }
}

// ---------- Live mode ----------

interface ChargilyApiCheckout {
  id: string
  status: ChargilyCheckoutStatus
  checkout_url: string
  updated_at: number
}

async function chargilyFetch<T>(path: string, init: RequestInit): Promise<T> {
  if (!CHARGILY_SECRET_KEY) {
    throw new Error('CHARGILY_MODE=live is set but CHARGILY_SECRET_KEY is missing.')
  }

  const res = await fetch(`${CHARGILY_BASE_URL}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${CHARGILY_SECRET_KEY}`,
      'Content-Type': 'application/json',
      ...init.headers,
    },
    // Payment calls should never hang indefinitely.
    signal: AbortSignal.timeout(15_000),
  })

  if (!res.ok) {
    const body = await res.text().catch(() => '')
    throw new Error(`Chargily API error ${res.status} on ${path}: ${body.slice(0, 300)}`)
  }

  return res.json() as Promise<T>
}

async function createCheckoutSessionLive(order: Order): Promise<CheckoutSessionResult> {
  const checkout = await chargilyFetch<ChargilyApiCheckout>('/checkouts', {
    method: 'POST',
    body: JSON.stringify({
      amount: order.totalDZD,
      currency: 'dzd',
      success_url: `${APP_URL}/order/${order.accessToken}`,
      failure_url: `${APP_URL}/order/${order.accessToken}`,
      // Round-trips our own order id through Chargily so it's recoverable
      // from their side too (e.g. from their dashboard) if ever needed.
      metadata: { orderId: order.id, orderNumber: order.orderNumber },
    }),
  })

  return { checkoutUrl: checkout.checkout_url, providerCheckoutId: checkout.id }
}

async function getCheckoutStatusLive(providerCheckoutId: string): Promise<CheckoutStatusResult> {
  const checkout = await chargilyFetch<ChargilyApiCheckout>(`/checkouts/${providerCheckoutId}`, {
    method: 'GET',
  })
  return {
    providerCheckoutId: checkout.id,
    status: checkout.status,
    updatedAt: checkout.updated_at,
  }
}

