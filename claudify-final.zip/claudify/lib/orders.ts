import { randomBytes } from 'crypto'
import { prisma } from '@/lib/prisma'
import type { Order } from '@prisma/client'

export function generateOrderNumber(): string {
  const rand = Math.floor(10000 + Math.random() * 90000)
  return `CLDF-${rand}`
}

export function generateAccessToken(): string {
  return randomBytes(24).toString('hex')
}

interface CreatePendingOrderInput {
  email: string
  items: { productId: string; quantity: number }[]
}

/**
 * Creates a pending order with server-verified prices — the client only
 * ever sends product ids and quantities, never amounts. Runs as a single
 * transaction so a partial order can never be left behind.
 */
export async function createPendingOrder({ email, items }: CreatePendingOrderInput) {
  if (items.length === 0) throw new Error('Cart is empty')

  const productIds = items.map((i) => i.productId)
  const products = await prisma.product.findMany({
    where: { id: { in: productIds }, status: 'published' },
  })
  if (products.length !== productIds.length) {
    throw new Error('One or more items in your cart are no longer available')
  }

  const totalDZD = items.reduce((sum, item) => {
    const product = products.find((p) => p.id === item.productId)!
    return sum + product.priceDZD * item.quantity
  }, 0)

  const customer = await prisma.customer.upsert({
    where: { email },
    update: {},
    create: { email },
  })

  const order = await prisma.order.create({
    data: {
      orderNumber: generateOrderNumber(),
      accessToken: generateAccessToken(),
      customerId: customer.id,
      totalDZD,
      status: 'pending',
      items: {
        create: items.map((item) => {
          const product = products.find((p) => p.id === item.productId)!
          return {
            productId: product.id,
            titleSnapshot: product.title,
            unitPriceDZD: product.priceDZD,
            quantity: item.quantity,
          }
        }),
      },
    },
    include: { items: true },
  })

  return order
}

export function getOrderByAccessToken(accessToken: string) {
  return prisma.order.findUnique({
    where: { accessToken },
    include: { items: { include: { product: true } } },
  })
}

/**
 * The only place an order is allowed to become `paid`. Idempotent: calling
 * this twice for an already-paid order is a no-op, so a retried poll or a
 * duplicate mock-mode callback can never double-apply a payment.
 */
export async function markOrderPaid(orderId: string, chargilyPaymentId?: string): Promise<Order> {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUniqueOrThrow({ where: { id: orderId } })
    if (order.status === 'paid') return order // already applied — idempotent

    const updated = await tx.order.update({
      where: { id: orderId },
      data: { status: 'paid', paidAt: new Date(), chargilyPaymentId },
    })

    if (updated.totalDZD >= 15000) {
      await tx.alert.create({
        data: {
          severity: 'info',
          type: 'high_value_order',
          message: `High-value order ${updated.orderNumber} paid: ${updated.totalDZD} DA`,
          relatedOrderId: updated.id,
        },
      })
    }

    return updated
  })
}

export async function markOrderFailed(orderId: string, reason: string): Promise<Order> {
  return prisma.order.update({
    where: { id: orderId },
    data: { status: 'failed', failureReason: reason },
  })
}

/**
 * Manual refund marker — this only ever runs when the store owner explicitly
 * triggers it from the admin dashboard (see lib/admin/actions/orders.ts). It
 * does not call any payment provider API to actually move money; refunding
 * the real payment through Chargily is a separate, manual step the owner
 * takes on Chargily's own dashboard. This just keeps our records honest.
 */
export async function markOrderRefunded(orderId: string): Promise<Order> {
  return prisma.order.update({
    where: { id: orderId },
    data: { status: 'refunded' },
  })
}
