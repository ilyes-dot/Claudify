import { FaqItem, Testimonial } from '@/lib/types'

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    name: 'Amine K.',
    role: 'Freelance designer, Oran',
    quote:
      'Bought the React dashboard kit at 11pm and was customizing it within five minutes of paying. No account, no waiting — the file was just there.',
    productSlug: 'react-admin-dashboard-ui-kit',
  },
  {
    id: 't2',
    name: 'Sarah B.',
    role: 'Small business owner, Algiers',
    quote:
      'The invoice kit finally made my devis look like they come from a real company. Clients started paying faster once the paperwork looked serious.',
    productSlug: 'invoice-kit-dz',
  },
  {
    id: 't3',
    name: 'Yacine M.',
    role: 'Student, Constantine',
    quote:
      'I was nervous about paying online, but the checkout felt trustworthy and I had a receipt in my inbox right away.',
    productSlug: 'freelancing-from-algeria',
  },
]

export const faqItems: FaqItem[] = [
  {
    question: 'How do I receive my file after paying?',
    answer:
      'As soon as your payment is confirmed, your download unlocks automatically on your order page and we send the same link to your email. Most orders confirm within a few minutes.',
  },
  {
    question: 'What payment methods do you accept?',
    answer:
      'We accept CIB and Edahabia cards through Chargily Pay, a secure Algerian payment processor. Your card details are handled entirely by Chargily — Claudify never sees or stores them.',
  },
  {
    question: 'What if my payment succeeds but I don\u2019t get access?',
    answer:
      'Our system automatically reconciles payment status with Chargily on a short interval. If something looks stuck, use "Check my order status" on your order page, or contact support with your order number and we\u2019ll resolve it manually.',
  },
  {
    question: 'Can I get a refund?',
    answer:
      'Because these are digital products delivered instantly, sales are generally final once a file has been downloaded. If a product is materially different from its description, contact us within 7 days and we\u2019ll review it case by case.',
  },
  {
    question: 'Do I need to create an account?',
    answer:
      'No. You check out with just your email. We\u2019ll use it to send your receipt and download link, and so you can look up your order later.',
  },
  {
    question: 'Can I use these products commercially?',
    answer:
      'License terms are listed on each product page. Most templates and assets include a commercial license; a few are personal-use only — always check the product\u2019s license line before purchase.',
  },
]
