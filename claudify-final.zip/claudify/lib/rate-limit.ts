/**
 * Best-effort in-memory rate limiting, keyed by IP. This is intentionally
 * simple (no Redis, no external service) to match the project's low-cost
 * priority.
 *
 * LIMITATION: on serverless hosting with multiple instances (e.g. Vercel),
 * this map isn't shared across instances, so the effective limit is looser
 * than the numbers below suggest. That's an acceptable tradeoff at this
 * scale — it still stops a single naive script from hammering an endpoint.
 * If abuse becomes a real problem, swap this for a shared store (e.g.
 * Upstash Redis) without changing any call site.
 */

interface Bucket {
  count: number
  resetAt: number
}

const buckets = new Map<string, Bucket>()

// Periodically forget old buckets so this map can't grow unbounded.
setInterval(() => {
  const now = Date.now()
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key)
  }
}, 5 * 60 * 1000).unref?.()

export function checkRateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now()
  const bucket = buckets.get(key)

  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs })
    return true
  }

  if (bucket.count >= limit) return false

  bucket.count++
  return true
}

export function getClientIp(req: Request): string {
  const forwarded = req.headers.get('x-forwarded-for')
  return forwarded?.split(',')[0]?.trim() || 'unknown'
}
