import { prisma } from '@/lib/prisma'

export function getCategories() {
  return prisma.category.findMany({ orderBy: { sortOrder: 'asc' } })
}

export function getCategoryBySlug(slug: string) {
  return prisma.category.findUnique({ where: { slug } })
}
