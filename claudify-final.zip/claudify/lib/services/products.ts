import { prisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'

// Only published products are ever visible on the storefront. Draft/archived
// products exist in the DB (so the admin can prep or retire them) but are
// filtered out here, at the single choke point every storefront query goes
// through — not re-implemented per page.
const PUBLISHED: Prisma.ProductWhereInput = { status: 'published' }

export function getPublishedProducts() {
  return prisma.product.findMany({
    where: PUBLISHED,
    include: { category: true },
    orderBy: { createdAt: 'desc' },
  })
}

export function getFeaturedProducts() {
  return prisma.product.findMany({
    where: { ...PUBLISHED, featured: true },
    include: { category: true },
    orderBy: { createdAt: 'desc' },
    take: 6,
  })
}

export function getProductBySlug(slug: string) {
  return prisma.product.findFirst({
    where: { slug, ...PUBLISHED },
    include: { category: true, files: { orderBy: { sortOrder: 'asc' } } },
  })
}

export async function getRelatedProducts(categoryId: string, excludeId: string, limit = 3) {
  return prisma.product.findMany({
    where: { ...PUBLISHED, categoryId, id: { not: excludeId } },
    include: { category: true },
    take: limit,
  })
}

/**
 * Real sales count, computed from paid orders rather than a stored counter —
 * so it can never drift from what actually happened.
 */
export function getProductSalesCount(productId: string) {
  return prisma.orderItem.count({
    where: { productId, order: { status: 'paid' } },
  })
}

export function getProductsByCategory(categorySlug: string) {
  return prisma.product.findMany({
    where: { ...PUBLISHED, category: { slug: categorySlug } },
    include: { category: true },
    orderBy: { createdAt: 'desc' },
  })
}
