import 'server-only'
import { randomBytes, createHash } from 'crypto'
import { cookies, headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { hash as argonHash, verify as argonVerify } from '@node-rs/argon2'
import { prisma } from '@/lib/prisma'
import { checkRateLimit } from '@/lib/rate-limit'
import type { AdminUser } from '@prisma/client'

const SESSION_COOKIE = 'claudify_admin_session'
const SESSION_TTL_MS = 12 * 60 * 60 * 1000 // 12 hours
const MAX_FAILED_ATTEMPTS = 5
const LOCKOUT_MS = 15 * 60 * 1000 // 15 minutes

function hashToken(rawToken: string): string {
  return createHash('sha256').update(rawToken).digest('hex')
}

export async function hashPassword(password: string): Promise<string> {
  return argonHash(password)
}

export async function verifyPassword(passwordHash: string, password: string): Promise<boolean> {
  try {
    return await argonVerify(passwordHash, password)
  } catch {
    return false
  }
}

interface LoginResult {
  ok: boolean
  error?: string
}

/**
 * Verifies credentials, applies simple DB-backed rate limiting (no external
 * service needed), and — on success — creates a session and sets the
 * cookie. This is called from the login page's server action.
 */
export async function login(email: string, password: string): Promise<LoginResult> {
  // IP-based limit, independent of the per-account DB lockout below — stops
  // one source from rapid-firing attempts across many different emails.
  const ip = headers().get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown'
  if (!checkRateLimit(`admin-login:${ip}`, 15, 5 * 60 * 1000)) {
    return { ok: false, error: 'Too many login attempts from this network. Please wait a few minutes.' }
  }

  const admin = await prisma.adminUser.findUnique({ where: { email: email.toLowerCase().trim() } })

  // Same generic error whether the email doesn't exist or the password is
  // wrong — never reveal which one it was.
  const genericError = 'Incorrect email or password.'

  if (!admin) return { ok: false, error: genericError }

  if (admin.lockedUntil && admin.lockedUntil > new Date()) {
    const minutesLeft = Math.ceil((admin.lockedUntil.getTime() - Date.now()) / 60000)
    return { ok: false, error: `Too many failed attempts. Try again in ${minutesLeft} minute(s).` }
  }

  const valid = await verifyPassword(admin.passwordHash, password)
  if (!valid) {
    const failedLoginCount = admin.failedLoginCount + 1
    const lockedUntil = failedLoginCount >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCKOUT_MS) : null
    await prisma.adminUser.update({
      where: { id: admin.id },
      data: { failedLoginCount, lockedUntil },
    })
    return { ok: false, error: genericError }
  }

  await prisma.adminUser.update({
    where: { id: admin.id },
    data: { failedLoginCount: 0, lockedUntil: null, lastLoginAt: new Date() },
  })

  await createSession(admin.id)
  return { ok: true }
}

async function createSession(adminId: string): Promise<void> {
  const rawToken = randomBytes(32).toString('hex')
  await prisma.adminSession.create({
    data: {
      adminId,
      tokenHash: hashToken(rawToken),
      expiresAt: new Date(Date.now() + SESSION_TTL_MS),
    },
  })

  cookies().set(SESSION_COOKIE, rawToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/admin',
    maxAge: SESSION_TTL_MS / 1000,
  })
}

/**
 * Returns the currently logged-in admin, or null. Safe to call anywhere in
 * a Server Component/Action — does not redirect.
 */
export async function getSessionAdmin(): Promise<AdminUser | null> {
  const rawToken = cookies().get(SESSION_COOKIE)?.value
  if (!rawToken) return null

  const session = await prisma.adminSession.findUnique({
    where: { tokenHash: hashToken(rawToken) },
    include: { admin: true },
  })
  if (!session || session.expiresAt < new Date()) return null

  return session.admin
}

/** Use at the top of every protected admin page/layout. Redirects if not authenticated. */
export async function requireAdmin(): Promise<AdminUser> {
  const admin = await getSessionAdmin()
  if (!admin) redirect('/admin/login')
  return admin
}

export async function logout(): Promise<void> {
  const rawToken = cookies().get(SESSION_COOKIE)?.value
  if (rawToken) {
    await prisma.adminSession.deleteMany({ where: { tokenHash: hashToken(rawToken) } }).catch(() => {})
  }
  cookies().delete(SESSION_COOKIE)
}
