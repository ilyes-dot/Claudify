import { prisma } from '@/lib/prisma'

export async function getDashboardStats() {
  const [revenueAgg, paidOrderCount, totalOrderCount, customerCount, bestSellersRaw, recentOrders, openAlerts] =
    await Promise.all([
      prisma.order.aggregate({ where: { status: 'paid' }, _sum: { totalDZD: true } }),
      prisma.order.count({ where: { status: 'paid' } }),
      prisma.order.count(),
      prisma.customer.count(),
      prisma.orderItem.groupBy({
        by: ['productId'],
        where: { order: { status: 'paid' } },
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 5,
      }),
      prisma.order.findMany({
        orderBy: { createdAt: 'desc' },
        take: 8,
        include: { customer: true },
      }),
      prisma.alert.count({ where: { resolved: false } }),
    ])

  const bestSellerProducts = await prisma.product.findMany({
    where: { id: { in: bestSellersRaw.map((b) => b.productId) } },
  })
  const bestSellers = bestSellersRaw.map((b) => ({
    product: bestSellerProducts.find((p) => p.id === b.productId)!,
    unitsSold: b._sum.quantity ?? 0,
  }))

  const revenueByDay = await prisma.$queryRaw<{ day: Date; revenue: bigint }[]>`
    SELECT date_trunc('day', "paidAt") as day, SUM("totalDZD")::bigint as revenue
    FROM "Order"
    WHERE status = 'paid' AND "paidAt" >= NOW() - INTERVAL '30 days'
    GROUP BY day
    ORDER BY day ASC
  `

  return {
    totalRevenueDZD: revenueAgg._sum.totalDZD ?? 0,
    paidOrderCount,
    totalOrderCount,
    conversionRate: totalOrderCount > 0 ? paidOrderCount / totalOrderCount : 0,
    customerCount,
    bestSellers,
    recentOrders,
    openAlertCount: openAlerts,
    revenueByDay: revenueByDay.map((r) => ({ day: r.day, revenueDZD: Number(r.revenue) })),
  }
}

export async function getOrderStatusBreakdown() {
  const rows = await prisma.order.groupBy({ by: ['status'], _count: { _all: true } })
  return rows.map((r) => ({ status: r.status, count: r._count._all }))
}
