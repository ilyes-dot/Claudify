import { prisma } from '@/lib/prisma'

export async function listCustomersForAdmin() {
  const customers = await prisma.customer.findMany({
    include: {
      orders: { select: { status: true, totalDZD: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return customers.map((c) => {
    const paidOrders = c.orders.filter((o) => o.status === 'paid')
    return {
      id: c.id,
      email: c.email,
      createdAt: c.createdAt,
      orderCount: c.orders.length,
      paidOrderCount: paidOrders.length,
      totalSpentDZD: paidOrders.reduce((sum, o) => sum + o.totalDZD, 0),
    }
  })
}
