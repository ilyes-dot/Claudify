import { prisma } from '@/lib/prisma'
import type { OrderStatus } from '@prisma/client'

const PAGE_SIZE = 25

export async function listOrdersForAdmin(opts: { status?: OrderStatus; page?: number }) {
  const page = opts.page && opts.page > 0 ? opts.page : 1

  const where = opts.status ? { status: opts.status } : {}
  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      include: { customer: true, items: true },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.order.count({ where }),
  ])

  return { orders, total, page, pageSize: PAGE_SIZE, totalPages: Math.ceil(total / PAGE_SIZE) }
}

export function getOrderForAdmin(id: string) {
  return prisma.order.findUnique({
    where: { id },
    include: {
      customer: true,
      items: { include: { product: true } },
      paymentEvents: { orderBy: { appliedAt: 'desc' } },
    },
  })
}
