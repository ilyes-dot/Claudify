import { prisma } from '@/lib/prisma'

export function listProductsForAdmin() {
  return prisma.product.findMany({
    include: { category: true, files: true, _count: { select: { orderItems: true } } },
    orderBy: { createdAt: 'desc' },
  })
}

export function getProductForEdit(id: string) {
  return prisma.product.findUnique({
    where: { id },
    include: { files: { orderBy: { sortOrder: 'asc' } } },
  })
}

export function listCategoriesForAdmin() {
  return prisma.category.findMany({ orderBy: { sortOrder: 'asc' } })
}
