'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { requireAdmin } from '@/lib/admin/auth'
import { prisma } from '@/lib/prisma'
import { runSyncWithRetry } from '@/lib/sync/run-sync'

const settingsSchema = z.object({
  interval: z.enum(['every_15_min', 'every_30_min', 'every_hour', 'once_daily']),
  enabled: z.coerce.boolean(),
})

export async function updateSyncSettingsAction(formData: FormData) {
  await requireAdmin()
  const data = settingsSchema.parse({
    interval: formData.get('interval'),
    enabled: formData.get('enabled') === 'on',
  })

  await prisma.syncSetting.upsert({
    where: { id: 'singleton' },
    update: data,
    create: { id: 'singleton', ...data },
  })

  revalidatePath('/admin/settings/sync')
}

export async function runSyncNowAction() {
  await requireAdmin()
  await runSyncWithRetry()
  revalidatePath('/admin/settings/sync')
  revalidatePath('/admin')
}
