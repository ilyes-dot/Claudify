'use server'

import { redirect } from 'next/navigation'
import { requireAdmin, verifyPassword, hashPassword } from '@/lib/admin/auth'
import { prisma } from '@/lib/prisma'

export async function changePasswordAction(formData: FormData) {
  const admin = await requireAdmin()

  const currentPassword = String(formData.get('currentPassword') || '')
  const newPassword = String(formData.get('newPassword') || '')
  const confirmPassword = String(formData.get('confirmPassword') || '')

  if (newPassword.length < 10) {
    redirect('/admin/settings/account?error=' + encodeURIComponent('New password must be at least 10 characters.'))
  }
  if (newPassword !== confirmPassword) {
    redirect('/admin/settings/account?error=' + encodeURIComponent('New passwords do not match.'))
  }

  const valid = await verifyPassword(admin.passwordHash, currentPassword)
  if (!valid) {
    redirect('/admin/settings/account?error=' + encodeURIComponent('Current password is incorrect.'))
  }

  const passwordHash = await hashPassword(newPassword)
  await prisma.adminUser.update({ where: { id: admin.id }, data: { passwordHash } })

  redirect('/admin/settings/account?success=1')
}
