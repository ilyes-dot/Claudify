'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { z } from 'zod'
import { requireAdmin } from '@/lib/admin/auth'
import { prisma } from '@/lib/prisma'
import { slugify } from '@/lib/utils'

const productSchema = z.object({
  title: z.string().trim().min(3).max(200),
  tagline: z.string().trim().min(3).max(300),
  description: z.string().trim().min(10),
  benefits: z.string().trim(), // one per line, split below
  priceDZD: z.coerce.number().int().min(0),
  compareAtDZD: z.coerce.number().int().min(0).optional().or(z.literal('')),
  categoryId: z.string().min(1),
  coverImage: z.string().trim().min(1),
  status: z.enum(['draft', 'published', 'archived']),
  featured: z.coerce.boolean().optional(),
  licenseNote: z.string().trim().min(1),
})

function parseProductForm(formData: FormData) {
  const raw = Object.fromEntries(formData.entries())
  const parsed = productSchema.parse(raw)
  return {
    ...parsed,
    benefits: parsed.benefits.split('\n').map((b) => b.trim()).filter(Boolean),
    compareAtDZD: parsed.compareAtDZD === '' || parsed.compareAtDZD === undefined ? null : Number(parsed.compareAtDZD),
    featured: raw.featured === 'on',
  }
}

export async function createProductAction(formData: FormData) {
  await requireAdmin()
  const data = parseProductForm(formData)
  const slug = `${slugify(data.title)}-${Math.random().toString(36).slice(2, 6)}`

  const product = await prisma.product.create({ data: { ...data, slug } })
  revalidatePath('/admin/products')
  redirect(`/admin/products/${product.id}`)
}

export async function updateProductAction(productId: string, formData: FormData) {
  await requireAdmin()
  const data = parseProductForm(formData)

  await prisma.product.update({ where: { id: productId }, data })
  revalidatePath('/admin/products')
  revalidatePath(`/admin/products/${productId}`)
  revalidatePath('/products') // storefront cache
}

export async function deleteProductAction(productId: string) {
  await requireAdmin()

  const orderCount = await prisma.orderItem.count({ where: { productId } })
  if (orderCount > 0) {
    throw new Error(
      `This product has ${orderCount} order(s) attached to it and can't be deleted — archive it instead so past orders stay intact.`
    )
  }

  await prisma.product.delete({ where: { id: productId } })
  revalidatePath('/admin/products')
  redirect('/admin/products')
}

const PRIVATE_STORAGE_ROOT = join(process.cwd(), 'private-storage')
const PUBLIC_UPLOADS_ROOT = join(process.cwd(), 'public', 'uploads', 'covers')

function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(0, 100)
}

/**
 * Writes to local disk. CONFIGURE FOR PRODUCTION on serverless hosts
 * (e.g. Vercel): the filesystem there is read-only/ephemeral at runtime,
 * so uploads made this way won't persist across deploys or instances.
 * Swap this for an S3-compatible adapter (see lib/storage.ts) before
 * relying on file uploads in that kind of production deployment. On a
 * regular VPS with a persistent disk, this works as-is.
 */
export async function uploadProductFileAction(productId: string, formData: FormData) {
  await requireAdmin()

  const file = formData.get('file') as File | null
  const label = String(formData.get('label') || '').trim()
  if (!file || file.size === 0) throw new Error('Choose a file to upload.')
  if (!label) throw new Error('Give this file a label (e.g. "Windows installer").')

  const product = await prisma.product.findUniqueOrThrow({ where: { id: productId } })
  const dir = join(PRIVATE_STORAGE_ROOT, 'products', product.slug)
  await mkdir(dir, { recursive: true })

  const fileName = sanitizeFileName(file.name)
  const storageKey = `products/${product.slug}/${fileName}`
  const buffer = Buffer.from(await file.arrayBuffer())
  await writeFile(join(dir, fileName), buffer)

  await prisma.productFile.create({
    data: { productId, label, storageKey, sizeBytes: buffer.byteLength },
  })

  revalidatePath(`/admin/products/${productId}`)
}

export async function deleteProductFileAction(productId: string, fileId: string) {
  await requireAdmin()
  await prisma.productFile.delete({ where: { id: fileId } })
  revalidatePath(`/admin/products/${productId}`)
}

export async function uploadCoverImageAction(formData: FormData): Promise<string> {
  await requireAdmin()

  const file = formData.get('file') as File | null
  if (!file || file.size === 0) throw new Error('Choose an image to upload.')

  await mkdir(PUBLIC_UPLOADS_ROOT, { recursive: true })
  const fileName = `${Date.now()}-${sanitizeFileName(file.name)}`
  const buffer = Buffer.from(await file.arrayBuffer())
  await writeFile(join(PUBLIC_UPLOADS_ROOT, fileName), buffer)

  return `/uploads/covers/${fileName}`
}
