'use server'

import { revalidatePath } from 'next/cache'
import { requireAdmin } from '@/lib/admin/auth'
import { prisma } from '@/lib/prisma'

export async function resolveAlertAction(alertId: string) {
  await requireAdmin()
  await prisma.alert.update({ where: { id: alertId }, data: { resolved: true } })
  revalidatePath('/admin/alerts')
  revalidatePath('/admin')
}
