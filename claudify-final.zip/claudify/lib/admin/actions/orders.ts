'use server'

import { revalidatePath } from 'next/cache'
import { requireAdmin } from '@/lib/admin/auth'
import { markOrderPaid, markOrderFailed, markOrderRefunded } from '@/lib/orders'

// Every action here is a manual override the owner explicitly triggers from
// the dashboard (never automatic, never triggered by a customer or a sync
// cycle) — see lib/orders.ts for what each actually changes.

export async function manuallyMarkPaidAction(orderId: string) {
  await requireAdmin()
  await markOrderPaid(orderId)
  revalidatePath(`/admin/orders/${orderId}`)
  revalidatePath('/admin/orders')
}

export async function manuallyMarkFailedAction(orderId: string) {
  await requireAdmin()
  await markOrderFailed(orderId, 'Manually marked as failed by store owner.')
  revalidatePath(`/admin/orders/${orderId}`)
  revalidatePath('/admin/orders')
}

export async function manuallyMarkRefundedAction(orderId: string) {
  await requireAdmin()
  await markOrderRefunded(orderId)
  revalidatePath(`/admin/orders/${orderId}`)
  revalidatePath('/admin/orders')
}
