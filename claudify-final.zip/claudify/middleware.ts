import { NextRequest, NextResponse } from 'next/server'

const SESSION_COOKIE = 'claudify_admin_session'

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl

  if (pathname.startsWith('/admin') && pathname !== '/admin/login') {
    const hasCookie = req.cookies.has(SESSION_COOKIE)
    if (!hasCookie) {
      const loginUrl = new URL('/admin/login', req.url)
      return NextResponse.redirect(loginUrl)
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/admin/:path*'],
}
